<?xml version="1.0" encoding="UTF-8"?>
<Ableton MajorVersion="5" MinorVersion="12.0_12300" SchemaChangeCount="1" Creator="Ableton Live 12.3.7" Revision="c92a51f02840318cf41b9f6331d918cd019e6edf">
	<LiveSet>
		<NextPointeeId Value="12720" />
		<OverwriteProtectionNumber Value="3075" />
		<LomId Value="0" />
		<LomIdView Value="0" />
		<Tracks>
			<AudioTrack Id="0" SelectedToolPanel="7" SelectedTransformationName="" SelectedGeneratorName="">
				<LomId Value="0" />
				<LomIdView Value="0" />
				<IsContentSelectedInDocument Value="true" />
				<PreferredContentViewMode Value="0" />
				<TrackDelay>
					<Value Value="0" />
					<IsValueSampleBased Value="false" />
				</TrackDelay>
				<Name>
					<EffectiveName Value="1-Audio" />
					<UserName Value="" />
					<Annotation Value="" />
					<MemorizedFirstClipName Value="" />
				</Name>
				<Color Value="41" />
				<AutomationEnvelopes>
					<Envelopes />
				</AutomationEnvelopes>
				<TrackGroupId Value="-1" />
				<TrackUnfolded Value="true" />
				<DevicesListWrapper LomId="0" />
				<ClipSlotsListWrapper LomId="0" />
				<ArrangementClipsListWrapper LomId="0" />
				<TakeLanesListWrapper LomId="0" />
				<ViewData Value='{"alternative_mode_locked": false, "push-instrument-selected-notes": [36], "push-note-repeat-rate": 0.5, "push-note-repeat-enabled": false, "push-selected-note-mode": "play"}' />
				<TakeLanes>
					<TakeLanes />
					<AreTakeLanesFolded Value="true" />
				</TakeLanes>
				<LinkedTrackGroupId Value="-1" />
				<SavedPlayingSlot Value="-1" />
				<SavedPlayingOffset Value="0" />
				<Freeze Value="false" />
				<NeedArrangerRefreeze Value="true" />
				<PostProcessFreezeClips Value="0" />
				<DeviceChain>
					<AutomationLanes>
						<AutomationLanes>
							<AutomationLane Id="0">
								<SelectedDevice Value="1" />
								<SelectedEnvelope Value="7" />
								<IsContentSelectedInDocument Value="false" />
								<LaneHeight Value="17" />
							</AutomationLane>
						</AutomationLanes>
						<AreAdditionalAutomationLanesFolded Value="false" />
					</AutomationLanes>
					<ClipEnvelopeChooserViewState>
						<SelectedDevice Value="1" />
						<SelectedEnvelope Value="7" />
						<PreferModulationVisible Value="false" />
					</ClipEnvelopeChooserViewState>
					<AudioInputRouting>
						<Target Value="AudioIn/External/M0" />
						<UpperDisplayString Value="Ext. In" />
						<LowerDisplayString Value="1" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</AudioInputRouting>
					<MidiInputRouting>
						<Target Value="MidiIn/External.All/-1" />
						<UpperDisplayString Value="Ext: All Ins" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</MidiInputRouting>
					<AudioOutputRouting>
						<Target Value="AudioOut/Main" />
						<UpperDisplayString Value="Master" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</AudioOutputRouting>
					<MidiOutputRouting>
						<Target Value="MidiOut/None" />
						<UpperDisplayString Value="None" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</MidiOutputRouting>
					<Mixer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="708">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10409" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="false" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<Sends>
							<TrackSendHolder Id="0">
								<Send>
									<LomId Value="0" />
									<Manual Value="0.00031622799" />
									<MidiControllerRange>
										<Min Value="0.00031622799" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="709">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="443">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Send>
								<EnabledByUser Value="true" />
							</TrackSendHolder>
							<TrackSendHolder Id="2">
								<Send>
									<LomId Value="0" />
									<Manual Value="0.0003162277571" />
									<MidiControllerRange>
										<Min Value="0.0003162277571" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1558">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1559">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Send>
								<EnabledByUser Value="true" />
							</TrackSendHolder>
						</Sends>
						<Speaker>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="711">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</Speaker>
						<SoloSink Value="false" />
						<PanMode Value="0" />
						<Pan>
							<LomId Value="0" />
							<Manual Value="0" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="712">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="286">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</Pan>
						<SplitStereoPanL>
							<LomId Value="0" />
							<Manual Value="-1" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="713">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="714">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</SplitStereoPanL>
						<SplitStereoPanR>
							<LomId Value="0" />
							<Manual Value="1" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="715">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="716">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</SplitStereoPanR>
						<Volume>
							<LomId Value="0" />
							<Manual Value="1" />
							<MidiControllerRange>
								<Min Value="0.00031622799" />
								<Max Value="1.99526203" />
							</MidiControllerRange>
							<AutomationTarget Id="717">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="287">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</Volume>
						<ViewStateSessionTrackWidth Value="74" />
						<CrossFadeState>
							<LomId Value="0" />
							<Manual Value="1" />
							<AutomationTarget Id="718">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiControllerRange>
								<Min Value="0" />
								<Max Value="2" />
							</MidiControllerRange>
						</CrossFadeState>
						<SendsListWrapper LomId="0" />
					</Mixer>
					<MainSequencer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="719">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10410" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="false" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<ClipSlotList>
							<ClipSlot Id="0">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="1">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="2">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="3">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="4">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="5">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="6">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="7">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
						</ClipSlotList>
						<MonitoringEnum Value="1" />
						<KeepRecordMonitoringLatency Value="false" />
						<Sample>
							<ArrangerAutomation>
								<Events />
								<AutomationTransformViewState>
									<IsTransformPending Value="false" />
									<TimeAndValueTransforms />
								</AutomationTransformViewState>
							</ArrangerAutomation>
						</Sample>
						<VolumeModulationTarget Id="288">
							<LockEnvelope Value="0" />
						</VolumeModulationTarget>
						<TranspositionModulationTarget Id="289">
							<LockEnvelope Value="0" />
						</TranspositionModulationTarget>
						<TransientEnvelopeModulationTarget Id="10829">
							<LockEnvelope Value="0" />
						</TransientEnvelopeModulationTarget>
						<GrainSizeModulationTarget Id="290">
							<LockEnvelope Value="0" />
						</GrainSizeModulationTarget>
						<FluxModulationTarget Id="291">
							<LockEnvelope Value="0" />
						</FluxModulationTarget>
						<SampleOffsetModulationTarget Id="292">
							<LockEnvelope Value="0" />
						</SampleOffsetModulationTarget>
						<ComplexProFormantsModulationTarget Id="10830">
							<LockEnvelope Value="0" />
						</ComplexProFormantsModulationTarget>
						<ComplexProEnvelopeModulationTarget Id="10831">
							<LockEnvelope Value="0" />
						</ComplexProEnvelopeModulationTarget>
						<PitchViewScrollPosition Value="-1073741824" />
						<SampleOffsetModulationScrollPosition Value="-1073741824" />
						<Recorder>
							<IsArmed Value="false" />
							<TakeCounter Value="1" />
						</Recorder>
					</MainSequencer>
					<FreezeSequencer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="720">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10411" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="false" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<ClipSlotList>
							<ClipSlot Id="0">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="1">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="2">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="3">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="4">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="5">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="6">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="7">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
						</ClipSlotList>
						<MonitoringEnum Value="1" />
						<KeepRecordMonitoringLatency Value="true" />
						<Sample>
							<ArrangerAutomation>
								<Events />
								<AutomationTransformViewState>
									<IsTransformPending Value="false" />
									<TimeAndValueTransforms />
								</AutomationTransformViewState>
							</ArrangerAutomation>
						</Sample>
						<VolumeModulationTarget Id="293">
							<LockEnvelope Value="0" />
						</VolumeModulationTarget>
						<TranspositionModulationTarget Id="294">
							<LockEnvelope Value="0" />
						</TranspositionModulationTarget>
						<TransientEnvelopeModulationTarget Id="10832">
							<LockEnvelope Value="0" />
						</TransientEnvelopeModulationTarget>
						<GrainSizeModulationTarget Id="295">
							<LockEnvelope Value="0" />
						</GrainSizeModulationTarget>
						<FluxModulationTarget Id="296">
							<LockEnvelope Value="0" />
						</FluxModulationTarget>
						<SampleOffsetModulationTarget Id="297">
							<LockEnvelope Value="0" />
						</SampleOffsetModulationTarget>
						<ComplexProFormantsModulationTarget Id="10833">
							<LockEnvelope Value="0" />
						</ComplexProFormantsModulationTarget>
						<ComplexProEnvelopeModulationTarget Id="10834">
							<LockEnvelope Value="0" />
						</ComplexProEnvelopeModulationTarget>
						<PitchViewScrollPosition Value="-1073741824" />
						<SampleOffsetModulationScrollPosition Value="-1073741824" />
						<Recorder>
							<IsArmed Value="false" />
							<TakeCounter Value="1" />
						</Recorder>
					</FreezeSequencer>
					<DeviceChain>
						<Devices>
							<AudioEffectGroupDevice Id="0">
								<LomId Value="0" />
								<LomIdView Value="0" />
								<IsExpanded Value="true" />
								<BreakoutIsExpanded Value="false" />
								<On>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="2226">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</On>
								<ModulationSourceCount Value="0" />
								<ParametersListWrapper LomId="0" />
								<Pointee Id="10412" />
								<LastSelectedTimeableIndex Value="7" />
								<LastSelectedClipEnvelopeIndex Value="7" />
								<LastPresetRef>
									<Value>
										</Value>
								</LastPresetRef>
								<LockedScripts />
								<IsFolded Value="false" />
								<ShouldShowPresetName Value="true" />
								<UserName Value="Channel Strip" />
								<Annotation Value="Channel Strip A provides the functionality found on analog mixer input channels." />
								<SourceContext>
									<Value>
										</Value>
								</SourceContext>
								<MpePitchBendUsesTuning Value="true" />
								<ViewData Value='{"x_axis": "Macro 3", "y_axis": "Macro 2"}' />
								<OverwriteProtectionNumber Value="3075" />
								<Branches>
									<AudioEffectBranch Id="0">
										<LomId Value="0" />
										<Name>
											<EffectiveName Value="EQ Eight | Gate | Channel EQ | Compressor" />
											<UserName Value="" />
											<Annotation Value="" />
											<MemorizedFirstClipName Value="" />
										</Name>
										<IsSelected Value="true" />
										<DeviceChain>
											<AudioToAudioDeviceChain Id="0">
												<Devices>
													<Eq8 Id="10">
														<LomId Value="0" />
														<LomIdView Value="0" />
														<IsExpanded Value="false" />
														<BreakoutIsExpanded Value="false" />
														<On>
															<LomId Value="0" />
															<Manual Value="true" />
															<AutomationTarget Id="4235">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="1" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</On>
														<ModulationSourceCount Value="0" />
														<ParametersListWrapper LomId="0" />
														<Pointee Id="10413" />
														<LastSelectedTimeableIndex Value="74" />
														<LastSelectedClipEnvelopeIndex Value="74" />
														<LastPresetRef>
															<Value>
																</Value>
														</LastPresetRef>
														<LockedScripts />
														<IsFolded Value="true" />
														<ShouldShowPresetName Value="false" />
														<UserName Value="EQ Eight" />
														<Annotation Value="" />
														<SourceContext>
															<Value />
														</SourceContext>
														<MpePitchBendUsesTuning Value="true" />
														<ViewData Value="{}" />
														<OverwriteProtectionNumber Value="3075" />
														<Precision Value="0" />
														<Mode Value="0" />
														<EditMode Value="false" />
														<SelectedBand Value="7" />
														<GlobalGain>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="0" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="0" />
															<MidiControllerRange>
																<Min Value="-12" />
																<Max Value="12" />
															</MidiControllerRange>
															<AutomationTarget Id="4236">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4237">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</GlobalGain>
														<Scale>
															<LomId Value="0" />
															<Manual Value="1" />
															<MidiControllerRange>
																<Min Value="-2" />
																<Max Value="2" />
															</MidiControllerRange>
															<AutomationTarget Id="4238">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4239">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Scale>
														<Bands.0>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<KeyMidi>
																		<PersistentKeyString Value="" />
																		<IsNote Value="false" />
																		<Channel Value="16" />
																		<NoteOrController Value="1" />
																		<LowerRangeNote Value="-1" />
																		<UpperRangeNote Value="-1" />
																		<ControllerMapMode Value="0" />
																	</KeyMidi>
																	<Manual Value="true" />
																	<AutomationTarget Id="4240">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="1" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="1" />
																	<AutomationTarget Id="4241">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<KeyMidi>
																		<PersistentKeyString Value="" />
																		<IsNote Value="false" />
																		<Channel Value="16" />
																		<NoteOrController Value="1" />
																		<LowerRangeNote Value="-1" />
																		<UpperRangeNote Value="-1" />
																		<ControllerMapMode Value="0" />
																	</KeyMidi>
																	<Manual Value="10" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="700" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4242">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4243">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4244">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4245">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="0.7534430623" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4246">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4247">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4248">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4249">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="100.000015" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4250">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4251">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4252">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4253">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4254">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4255">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.0>
														<Bands.1>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4256">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4257">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="400.000214" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4258">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4259">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4260">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4261">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="0.7000000477" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4262">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4263">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4264">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4265">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="500.000244" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4266">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4267">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4268">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4269">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4270">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4271">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.1>
														<Bands.2>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4272">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4273">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="1600.00073" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4274">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4275">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4276">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4277">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="0.7000000477" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4278">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4279">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4280">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4281">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="2000.00024" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4282">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4283">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4284">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4285">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4286">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4287">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.2>
														<Bands.3>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4288">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4289">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="3000.00171" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4290">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4291">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4292">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4293">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="0.7000000477" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4294">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4295">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="true" />
																	<AutomationTarget Id="4296">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4297">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="10000.0049" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4298">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4299">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4300">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4301">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4302">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4303">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.3>
														<Bands.4>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4304">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4305">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="50" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4306">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4307">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4308">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4309">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4310">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4311">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4312">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4313">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="50" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4314">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4315">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4316">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4317">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4318">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4319">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.4>
														<Bands.5>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4320">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4321">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="200.000046" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4322">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4323">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4324">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4325">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4326">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4327">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4328">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4329">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="200.000046" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4330">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4331">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4332">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4333">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4334">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4335">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.5>
														<Bands.6>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4336">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4337">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="1000.00031" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4338">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4339">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4340">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4341">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4342">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4343">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4344">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4345">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="1000.00031" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4346">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4347">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4348">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4349">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4350">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4351">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.6>
														<Bands.7>
															<ParameterA>
																<IsOn>
																	<LomId Value="0" />
																	<KeyMidi>
																		<PersistentKeyString Value="" />
																		<IsNote Value="false" />
																		<Channel Value="16" />
																		<NoteOrController Value="2" />
																		<LowerRangeNote Value="-1" />
																		<UpperRangeNote Value="-1" />
																		<ControllerMapMode Value="0" />
																	</KeyMidi>
																	<Manual Value="true" />
																	<AutomationTarget Id="4352">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="0" />
																		<Max Value="126" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="6" />
																	<AutomationTarget Id="4353">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<KeyMidi>
																		<PersistentKeyString Value="" />
																		<IsNote Value="false" />
																		<Channel Value="16" />
																		<NoteOrController Value="2" />
																		<LowerRangeNote Value="-1" />
																		<UpperRangeNote Value="-1" />
																		<ControllerMapMode Value="0" />
																	</KeyMidi>
																	<Manual Value="22000" />
																	<MidiControllerRange>
																		<Min Value="800" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4354">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4355">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4356">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4357">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="0.7500001788" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4358">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4359">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterA>
															<ParameterB>
																<IsOn>
																	<LomId Value="0" />
																	<Manual Value="false" />
																	<AutomationTarget Id="4360">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiCCOnOffThresholds>
																		<Min Value="64" />
																		<Max Value="127" />
																	</MidiCCOnOffThresholds>
																</IsOn>
																<Mode>
																	<LomId Value="0" />
																	<Manual Value="3" />
																	<AutomationTarget Id="4361">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<MidiControllerRange>
																		<Min Value="0" />
																		<Max Value="7" />
																	</MidiControllerRange>
																</Mode>
																<Freq>
																	<LomId Value="0" />
																	<Manual Value="5000.00098" />
																	<MidiControllerRange>
																		<Min Value="10" />
																		<Max Value="22000" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4362">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4363">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Freq>
																<Gain>
																	<LomId Value="0" />
																	<Manual Value="0" />
																	<MidiControllerRange>
																		<Min Value="-15" />
																		<Max Value="15" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4364">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4365">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Gain>
																<Q>
																	<LomId Value="0" />
																	<Manual Value="1.00000012" />
																	<MidiControllerRange>
																		<Min Value="0.1000000015" />
																		<Max Value="18" />
																	</MidiControllerRange>
																	<AutomationTarget Id="4366">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="4367">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Q>
															</ParameterB>
														</Bands.7>
														<SpectrumAnalyzer>
															<LomId Value="0" />
															<LomIdView Value="0" />
															<IsExpanded Value="false" />
															<BreakoutIsExpanded Value="false" />
															<On>
																<LomId Value="0" />
																<Manual Value="true" />
																<AutomationTarget Id="4368">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<MidiCCOnOffThresholds>
																	<Min Value="64" />
																	<Max Value="127" />
																</MidiCCOnOffThresholds>
															</On>
															<ModulationSourceCount Value="0" />
															<ParametersListWrapper LomId="0" />
															<Pointee Id="10414" />
															<LastSelectedTimeableIndex Value="0" />
															<LastSelectedClipEnvelopeIndex Value="0" />
															<LastPresetRef>
																<Value />
															</LastPresetRef>
															<LockedScripts />
															<IsFolded Value="false" />
															<ShouldShowPresetName Value="true" />
															<UserName Value="" />
															<Annotation Value="" />
															<SourceContext>
																<Value />
															</SourceContext>
															<MpePitchBendUsesTuning Value="true" />
															<ViewData Value="{}" />
															<OverwriteProtectionNumber Value="3075" />
															<ScaleYBegin Value="0" />
															<ScaleYRange Value="80" />
															<AutoScaleY Value="false" />
															<ScaleXMode Value="1" />
															<ShowBins Value="false" />
															<ShowMax Value="true" />
															<AnalyzeOn Value="true" />
															<Length Value="2" />
															<Window Value="3" />
															<ChannelMode Value="2" />
															<NumAverages Value="1" />
															<MinRefreshTime Value="60" />
														</SpectrumAnalyzer>
														<Live8ShelfScaleLegacyMode Value="false" />
														<AuditionOnOff Value="false" />
														<AdaptiveQFactor Value="1.12" />
														<AdaptiveQ>
															<LomId Value="0" />
															<Manual Value="false" />
															<AutomationTarget Id="4369">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</AdaptiveQ>
														<AdaptiveQAffectsShelves Value="true" />
													</Eq8>
													<Gate Id="9">
														<LomId Value="0" />
														<LomIdView Value="0" />
														<IsExpanded Value="false" />
														<BreakoutIsExpanded Value="false" />
														<On>
															<LomId Value="0" />
															<Manual Value="true" />
															<AutomationTarget Id="2271">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</On>
														<ModulationSourceCount Value="0" />
														<ParametersListWrapper LomId="0" />
														<Pointee Id="10415" />
														<LastSelectedTimeableIndex Value="0" />
														<LastSelectedClipEnvelopeIndex Value="0" />
														<LastPresetRef>
															<Value>
																</Value>
														</LastPresetRef>
														<LockedScripts />
														<IsFolded Value="true" />
														<ShouldShowPresetName Value="false" />
														<UserName Value="" />
														<Annotation Value="" />
														<SourceContext>
															<Value />
														</SourceContext>
														<MpePitchBendUsesTuning Value="true" />
														<ViewData Value="{}" />
														<OverwriteProtectionNumber Value="3075" />
														<Threshold>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="3" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="0.009999998845" />
															<MidiControllerRange>
																<Min Value="0.009999999776" />
																<Max Value="1.41253757" />
															</MidiControllerRange>
															<AutomationTarget Id="2272">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2273">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Threshold>
														<Attack>
															<LomId Value="0" />
															<Manual Value="0.01999999955" />
															<MidiControllerRange>
																<Min Value="0.01999999955" />
																<Max Value="150" />
															</MidiControllerRange>
															<AutomationTarget Id="2274">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2275">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Attack>
														<Hold>
															<LomId Value="0" />
															<Manual Value="20.0000019" />
															<MidiControllerRange>
																<Min Value="1" />
																<Max Value="1500" />
															</MidiControllerRange>
															<AutomationTarget Id="2276">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2277">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Hold>
														<Release>
															<LomId Value="0" />
															<Manual Value="99.9999619" />
															<MidiControllerRange>
																<Min Value="0.1000000015" />
																<Max Value="3000" />
															</MidiControllerRange>
															<AutomationTarget Id="2278">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2279">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Release>
														<Return>
															<LomId Value="0" />
															<Manual Value="0" />
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="24" />
															</MidiControllerRange>
															<AutomationTarget Id="2280">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2281">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Return>
														<Gain>
															<LomId Value="0" />
															<Manual Value="-40.0195312" />
															<MidiControllerRange>
																<Min Value="-75" />
																<Max Value="0" />
															</MidiControllerRange>
															<AutomationTarget Id="2282">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2283">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Gain>
														<SideChain>
															<OnOff>
																<LomId Value="0" />
																<Manual Value="false" />
																<AutomationTarget Id="2284">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<MidiCCOnOffThresholds>
																	<Min Value="64" />
																	<Max Value="127" />
																</MidiCCOnOffThresholds>
															</OnOff>
															<RoutedInput>
																<Routable>
																	<Target Value="AudioIn/None" />
																	<UpperDisplayString Value="No Output" />
																	<LowerDisplayString Value="" />
																	<MpeSettings>
																		<ZoneType Value="0" />
																		<FirstNoteChannel Value="1" />
																		<LastNoteChannel Value="15" />
																	</MpeSettings>
																	<MpePitchBendUsesTuning Value="true" />
																</Routable>
																<Volume>
																	<LomId Value="0" />
																	<Manual Value="1" />
																	<MidiControllerRange>
																		<Min Value="0.0003162277571" />
																		<Max Value="15.8489332" />
																	</MidiControllerRange>
																	<AutomationTarget Id="2285">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="2286">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Volume>
															</RoutedInput>
															<DryWet>
																<LomId Value="0" />
																<Manual Value="1" />
																<MidiControllerRange>
																	<Min Value="0" />
																	<Max Value="1" />
																</MidiControllerRange>
																<AutomationTarget Id="2287">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<ModulationTarget Id="2288">
																	<LockEnvelope Value="0" />
																</ModulationTarget>
															</DryWet>
														</SideChain>
														<SideListen>
															<LomId Value="0" />
															<Manual Value="false" />
															<AutomationTarget Id="2289">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</SideListen>
														<SideChainEq>
															<On>
																<LomId Value="0" />
																<Manual Value="false" />
																<AutomationTarget Id="2290">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<MidiCCOnOffThresholds>
																	<Min Value="64" />
																	<Max Value="127" />
																</MidiCCOnOffThresholds>
															</On>
															<Mode>
																<LomId Value="0" />
																<Manual Value="5" />
																<AutomationTarget Id="2291">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<MidiControllerRange>
																	<Min Value="0" />
																	<Max Value="5" />
																</MidiControllerRange>
															</Mode>
															<Freq>
																<LomId Value="0" />
																<Manual Value="200" />
																<MidiControllerRange>
																	<Min Value="30" />
																	<Max Value="15000" />
																</MidiControllerRange>
																<AutomationTarget Id="2292">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<ModulationTarget Id="2293">
																	<LockEnvelope Value="0" />
																</ModulationTarget>
															</Freq>
															<Q>
																<LomId Value="0" />
																<Manual Value="0.7071067691" />
																<MidiControllerRange>
																	<Min Value="0.1000000015" />
																	<Max Value="12" />
																</MidiControllerRange>
																<AutomationTarget Id="2294">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<ModulationTarget Id="2295">
																	<LockEnvelope Value="0" />
																</ModulationTarget>
															</Q>
															<Gain>
																<LomId Value="0" />
																<Manual Value="0" />
																<MidiControllerRange>
																	<Min Value="-15" />
																	<Max Value="15" />
																</MidiControllerRange>
																<AutomationTarget Id="2296">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<ModulationTarget Id="2297">
																	<LockEnvelope Value="0" />
																</ModulationTarget>
															</Gain>
														</SideChainEq>
														<FlipMode>
															<LomId Value="0" />
															<Manual Value="0" />
															<AutomationTarget Id="2298">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="1" />
															</MidiControllerRange>
														</FlipMode>
														<Live8LegacyMode Value="false" />
														<LookAhead>
															<LomId Value="0" />
															<Manual Value="1" />
															<AutomationTarget Id="2299">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="2" />
															</MidiControllerRange>
														</LookAhead>
													</Gate>
													<ChannelEq Id="4">
														<LomId Value="0" />
														<LomIdView Value="0" />
														<IsExpanded Value="true" />
														<BreakoutIsExpanded Value="false" />
														<On>
															<LomId Value="0" />
															<Manual Value="true" />
															<AutomationTarget Id="4202">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</On>
														<ModulationSourceCount Value="0" />
														<ParametersListWrapper LomId="0" />
														<Pointee Id="10416" />
														<LastSelectedTimeableIndex Value="4" />
														<LastSelectedClipEnvelopeIndex Value="4" />
														<LastPresetRef>
															<Value>
																</Value>
														</LastPresetRef>
														<LockedScripts />
														<IsFolded Value="true" />
														<ShouldShowPresetName Value="true" />
														<UserName Value="" />
														<Annotation Value="" />
														<SourceContext>
															<Value>
																<BranchSourceContext Id="0">
																	<OriginalFileRef>
																		<FileRef Id="0">
																			<RelativePathType Value="5" />
																			<RelativePath Value="Devices/Audio Effects/Channel EQ" />
																			<Path Value="/Applications/Ableton Live 12 Suite.app/Contents/App-Resources/Core Library/Devices/Audio Effects/Channel EQ" />
																			<Type Value="2" />
																			<LivePackName Value="Core Library" />
																			<LivePackId Value="www.ableton.com/0" />
																			<OriginalFileSize Value="0" />
																			<OriginalCrc Value="0" />
																			<SourceHint Value="" />
																		</FileRef>
																	</OriginalFileRef>
																	<BrowserContentPath Value="query:AudioFx#Channel%20EQ" />
																	<LocalFiltersJson Value="" />
																	<PresetRef>
																		<AbletonDefaultPresetRef Id="0" /></PresetRef>
																	<BranchDeviceId Value="" />
																</BranchSourceContext>
															</Value>
														</SourceContext>
														<MpePitchBendUsesTuning Value="true" />
														<ViewData Value="{}" />
														<OverwriteProtectionNumber Value="3075" />
														<HighpassOn>
															<LomId Value="0" />
															<Manual Value="false" />
															<AutomationTarget Id="4204">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</HighpassOn>
														<LowShelfGain>
															<LomId Value="0" />
															<Manual Value="1" />
															<MidiControllerRange>
																<Min Value="0.1800000072" />
																<Max Value="5.60000134" />
															</MidiControllerRange>
															<AutomationTarget Id="4205">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4206">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</LowShelfGain>
														<MidGain>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="4" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="1" />
															<MidiControllerRange>
																<Min Value="0.25" />
																<Max Value="4" />
															</MidiControllerRange>
															<AutomationTarget Id="4207">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4208">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</MidGain>
														<MidFrequency>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="5" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="1500.00012" />
															<MidiControllerRange>
																<Min Value="119.999985" />
																<Max Value="7500.00049" />
															</MidiControllerRange>
															<AutomationTarget Id="4209">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4210">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</MidFrequency>
														<HighShelfGain>
															<LomId Value="0" />
															<Manual Value="1" />
															<MidiControllerRange>
																<Min Value="0.1800000072" />
																<Max Value="5.60000134" />
															</MidiControllerRange>
															<AutomationTarget Id="4211">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4212">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</HighShelfGain>
														<Gain>
															<LomId Value="0" />
															<Manual Value="1" />
															<MidiControllerRange>
																<Min Value="0.25" />
																<Max Value="4" />
															</MidiControllerRange>
															<AutomationTarget Id="4213">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="4214">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Gain>
													</ChannelEq>
													<Compressor2 Id="2">
														<LomId Value="0" />
														<LomIdView Value="0" />
														<IsExpanded Value="false" />
														<BreakoutIsExpanded Value="false" />
														<On>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="6" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="true" />
															<AutomationTarget Id="2300">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="1" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</On>
														<ModulationSourceCount Value="0" />
														<ParametersListWrapper LomId="0" />
														<Pointee Id="10419" />
														<LastSelectedTimeableIndex Value="0" />
														<LastSelectedClipEnvelopeIndex Value="0" />
														<LastPresetRef>
															<Value>
																</Value>
														</LastPresetRef>
														<LockedScripts />
														<IsFolded Value="true" />
														<ShouldShowPresetName Value="false" />
														<UserName Value="" />
														<Annotation Value="" />
														<SourceContext>
															<Value />
														</SourceContext>
														<MpePitchBendUsesTuning Value="true" />
														<ViewData Value="{}" />
														<OverwriteProtectionNumber Value="3075" />
														<Threshold>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="7" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="1.33352172" />
															<MidiControllerRange>
																<Min Value="0.0005011872854" />
																<Max Value="1.90095174" />
															</MidiControllerRange>
															<AutomationTarget Id="2301">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2302">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Threshold>
														<Ratio>
															<LomId Value="0" />
															<KeyMidi>
																<PersistentKeyString Value="" />
																<IsNote Value="false" />
																<Channel Value="16" />
																<NoteOrController Value="6" />
																<LowerRangeNote Value="-1" />
																<UpperRangeNote Value="-1" />
																<ControllerMapMode Value="0" />
															</KeyMidi>
															<Manual Value="340282326356119256160033759537265639424" />
															<MidiControllerRange>
																<Min Value="1" />
																<Max Value="340282326356119256160033759537265639424" />
															</MidiControllerRange>
															<AutomationTarget Id="2303">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2304">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Ratio>
														<ExpansionRatio>
															<LomId Value="0" />
															<Manual Value="1.14999998" />
															<MidiControllerRange>
																<Min Value="1" />
																<Max Value="2" />
															</MidiControllerRange>
															<AutomationTarget Id="2305">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2306">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</ExpansionRatio>
														<Attack>
															<LomId Value="0" />
															<Manual Value="5.20637369" />
															<MidiControllerRange>
																<Min Value="0.009999999776" />
																<Max Value="1000" />
															</MidiControllerRange>
															<AutomationTarget Id="2307">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2308">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Attack>
														<Release>
															<LomId Value="0" />
															<Manual Value="449.174103" />
															<MidiControllerRange>
																<Min Value="1" />
																<Max Value="3000" />
															</MidiControllerRange>
															<AutomationTarget Id="2309">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2310">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Release>
														<AutoReleaseControlOnOff>
															<LomId Value="0" />
															<Manual Value="false" />
															<AutomationTarget Id="2311">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</AutoReleaseControlOnOff>
														<Gain>
															<LomId Value="0" />
															<Manual Value="0" />
															<MidiControllerRange>
																<Min Value="-36" />
																<Max Value="36" />
															</MidiControllerRange>
															<AutomationTarget Id="2312">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2313">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Gain>
														<GainCompensation>
															<LomId Value="0" />
															<Manual Value="true" />
															<AutomationTarget Id="2314">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</GainCompensation>
														<DryWet>
															<LomId Value="0" />
															<Manual Value="1" />
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="1" />
															</MidiControllerRange>
															<AutomationTarget Id="2315">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2316">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</DryWet>
														<Model>
															<LomId Value="0" />
															<Manual Value="0" />
															<AutomationTarget Id="2317">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="2" />
															</MidiControllerRange>
														</Model>
														<LegacyModel>
															<LomId Value="0" />
															<Manual Value="2" />
															<AutomationTarget Id="2318">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="2" />
															</MidiControllerRange>
														</LegacyModel>
														<LogEnvelope>
															<LomId Value="0" />
															<Manual Value="true" />
															<AutomationTarget Id="2319">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</LogEnvelope>
														<LegacyEnvFollowerMode>
															<LomId Value="0" />
															<Manual Value="1" />
															<AutomationTarget Id="2320">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="2" />
															</MidiControllerRange>
														</LegacyEnvFollowerMode>
														<Knee>
															<LomId Value="0" />
															<Manual Value="6" />
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="18" />
															</MidiControllerRange>
															<AutomationTarget Id="2321">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2322">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</Knee>
														<LookAhead>
															<LomId Value="0" />
															<Manual Value="1" />
															<AutomationTarget Id="2323">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="2" />
															</MidiControllerRange>
														</LookAhead>
														<SideListen>
															<LomId Value="0" />
															<Manual Value="false" />
															<AutomationTarget Id="2324">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</SideListen>
														<SideChain>
															<OnOff>
																<LomId Value="0" />
																<Manual Value="false" />
																<AutomationTarget Id="2325">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<MidiCCOnOffThresholds>
																	<Min Value="64" />
																	<Max Value="127" />
																</MidiCCOnOffThresholds>
															</OnOff>
															<RoutedInput>
																<Routable>
																	<Target Value="AudioIn/None" />
																	<UpperDisplayString Value="No Output" />
																	<LowerDisplayString Value="" />
																	<MpeSettings>
																		<ZoneType Value="0" />
																		<FirstNoteChannel Value="1" />
																		<LastNoteChannel Value="15" />
																	</MpeSettings>
																	<MpePitchBendUsesTuning Value="true" />
																</Routable>
																<Volume>
																	<LomId Value="0" />
																	<Manual Value="1" />
																	<MidiControllerRange>
																		<Min Value="0.0003162277571" />
																		<Max Value="15.8489332" />
																	</MidiControllerRange>
																	<AutomationTarget Id="2326">
																		<LockEnvelope Value="0" />
																	</AutomationTarget>
																	<ModulationTarget Id="2327">
																		<LockEnvelope Value="0" />
																	</ModulationTarget>
																</Volume>
															</RoutedInput>
															<DryWet>
																<LomId Value="0" />
																<Manual Value="1" />
																<MidiControllerRange>
																	<Min Value="0" />
																	<Max Value="1" />
																</MidiControllerRange>
																<AutomationTarget Id="2328">
																	<LockEnvelope Value="0" />
																</AutomationTarget>
																<ModulationTarget Id="2329">
																	<LockEnvelope Value="0" />
																</ModulationTarget>
															</DryWet>
														</SideChain>
														<SideChainEq_On>
															<LomId Value="0" />
															<Manual Value="false" />
															<AutomationTarget Id="2330">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiCCOnOffThresholds>
																<Min Value="64" />
																<Max Value="127" />
															</MidiCCOnOffThresholds>
														</SideChainEq_On>
														<SideChainEq_Mode>
															<LomId Value="0" />
															<Manual Value="4" />
															<AutomationTarget Id="2331">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<MidiControllerRange>
																<Min Value="0" />
																<Max Value="5" />
															</MidiControllerRange>
														</SideChainEq_Mode>
														<SideChainEq_Freq>
															<LomId Value="0" />
															<Manual Value="800.000366" />
															<MidiControllerRange>
																<Min Value="30" />
																<Max Value="15000" />
															</MidiControllerRange>
															<AutomationTarget Id="2332">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2333">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</SideChainEq_Freq>
														<SideChainEq_Q>
															<LomId Value="0" />
															<Manual Value="0.7071067691" />
															<MidiControllerRange>
																<Min Value="0.1000000015" />
																<Max Value="12" />
															</MidiControllerRange>
															<AutomationTarget Id="2334">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2335">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</SideChainEq_Q>
														<SideChainEq_Gain>
															<LomId Value="0" />
															<Manual Value="0" />
															<MidiControllerRange>
																<Min Value="-15" />
																<Max Value="15" />
															</MidiControllerRange>
															<AutomationTarget Id="2336">
																<LockEnvelope Value="0" />
															</AutomationTarget>
															<ModulationTarget Id="2337">
																<LockEnvelope Value="0" />
															</ModulationTarget>
														</SideChainEq_Gain>
														<Live8LegacyMode Value="false" />
														<ViewMode Value="1" />
														<IsOutputCurveVisible Value="false" />
														<RmsTimeShort Value="8" />
														<RmsTimeLong Value="250" />
														<ReleaseTimeShort Value="15" />
														<ReleaseTimeLong Value="1500" />
														<CrossfaderSmoothingTime Value="10" />
													</Compressor2>
												</Devices>
												<SignalModulations />
											</AudioToAudioDeviceChain>
										</DeviceChain>
										<BranchSelectorRange>
											<Min Value="0" />
											<Max Value="127" />
											<CrossfadeMin Value="0" />
											<CrossfadeMax Value="127" />
										</BranchSelectorRange>
										<IsSoloed Value="false" />
										<SessionViewBranchWidth Value="55" />
										<IsHighlightedInSessionView Value="false" />
										<SourceContext>
											<Value />
										</SourceContext>
										<Color Value="41" />
										<AutoColored Value="true" />
										<AutoColorScheme Value="0" />
										<SoloActivatedInSessionMixer Value="false" />
										<DevicesListWrapper LomId="0" />
										<MixerDevice>
											<LomId Value="0" />
											<LomIdView Value="0" />
											<IsExpanded Value="true" />
											<BreakoutIsExpanded Value="false" />
											<On>
												<LomId Value="0" />
												<Manual Value="true" />
												<AutomationTarget Id="2245">
													<LockEnvelope Value="0" />
												</AutomationTarget>
												<MidiCCOnOffThresholds>
													<Min Value="64" />
													<Max Value="127" />
												</MidiCCOnOffThresholds>
											</On>
											<ModulationSourceCount Value="0" />
											<ParametersListWrapper LomId="0" />
											<Pointee Id="10420" />
											<LastSelectedTimeableIndex Value="0" />
											<LastSelectedClipEnvelopeIndex Value="0" />
											<LastPresetRef>
												<Value>
													</Value>
											</LastPresetRef>
											<LockedScripts />
											<IsFolded Value="false" />
											<ShouldShowPresetName Value="false" />
											<UserName Value="AudioBranchMixerDevice" />
											<Annotation Value="" />
											<SourceContext>
												<Value />
											</SourceContext>
											<MpePitchBendUsesTuning Value="true" />
											<ViewData Value="{}" />
											<OverwriteProtectionNumber Value="3075" />
											<Speaker>
												<LomId Value="0" />
												<Manual Value="true" />
												<AutomationTarget Id="2246">
													<LockEnvelope Value="0" />
												</AutomationTarget>
												<MidiCCOnOffThresholds>
													<Min Value="64" />
													<Max Value="127" />
												</MidiCCOnOffThresholds>
											</Speaker>
											<Volume>
												<LomId Value="0" />
												<Manual Value="1" />
												<MidiControllerRange>
													<Min Value="0.0003162277571" />
													<Max Value="1.99526238" />
												</MidiControllerRange>
												<AutomationTarget Id="2247">
													<LockEnvelope Value="0" />
												</AutomationTarget>
												<ModulationTarget Id="2248">
													<LockEnvelope Value="0" />
												</ModulationTarget>
											</Volume>
											<Panorama>
												<LomId Value="0" />
												<Manual Value="0" />
												<MidiControllerRange>
													<Min Value="-1" />
													<Max Value="1" />
												</MidiControllerRange>
												<AutomationTarget Id="2249">
													<LockEnvelope Value="0" />
												</AutomationTarget>
												<ModulationTarget Id="2250">
													<LockEnvelope Value="0" />
												</ModulationTarget>
											</Panorama>
											<SendInfos />
											<RoutingHelper>
												<Routable>
													<Target Value="AudioOut/None" />
													<UpperDisplayString Value="No Output" />
													<LowerDisplayString Value="" />
													<MpeSettings>
														<ZoneType Value="0" />
														<FirstNoteChannel Value="1" />
														<LastNoteChannel Value="15" />
													</MpeSettings>
													<MpePitchBendUsesTuning Value="true" />
												</Routable>
												<TargetEnum Value="0" />
											</RoutingHelper>
											<SendsListWrapper LomId="0" />
										</MixerDevice>
									</AudioEffectBranch>
								</Branches>
								<IsBranchesListVisible Value="false" />
								<IsReturnBranchesListVisible Value="false" />
								<IsRangesEditorVisible Value="false" />
								<AreDevicesVisible Value="false" />
								<NumVisibleMacroControls Value="8" />
								<MacroControls.0>
									<LomId Value="0" />
									<Manual Value="63.5" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2227">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2228">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.0>
								<MacroControls.1>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2229">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2230">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.1>
								<MacroControls.2>
									<LomId Value="0" />
									<Manual Value="127" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2231">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2232">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.2>
								<MacroControls.3>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2233">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2234">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.3>
								<MacroControls.4>
									<LomId Value="0" />
									<Manual Value="63.5" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2235">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2236">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.4>
								<MacroControls.5>
									<LomId Value="0" />
									<Manual Value="77.5706482" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2237">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2238">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.5>
								<MacroControls.6>
									<LomId Value="0" />
									<Manual Value="95.25" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2239">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2240">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.6>
								<MacroControls.7>
									<LomId Value="0" />
									<Manual Value="117.002304" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2241">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2242">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.7>
								<MacroControls.8>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9370">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9371">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.8>
								<MacroControls.9>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9372">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9373">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.9>
								<MacroControls.10>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9374">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9375">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.10>
								<MacroControls.11>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9376">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9377">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.11>
								<MacroControls.12>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9378">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9379">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.12>
								<MacroControls.13>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9380">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9381">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.13>
								<MacroControls.14>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9382">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9383">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.14>
								<MacroControls.15>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="9384">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="9385">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MacroControls.15>
								<MacroDisplayNames.0 Value="Gain" />
								<MacroDisplayNames.1 Value="Hi Pass Filter" />
								<MacroDisplayNames.2 Value="Lo Pass Filter" />
								<MacroDisplayNames.3 Value="Gate Thresh" />
								<MacroDisplayNames.4 Value="Mid Gain" />
								<MacroDisplayNames.5 Value="Mid Freq" />
								<MacroDisplayNames.6 Value="Comp Ratio" />
								<MacroDisplayNames.7 Value="Comp Thresh" />
								<MacroDisplayNames.8 Value="Macro 9" />
								<MacroDisplayNames.9 Value="Macro 10" />
								<MacroDisplayNames.10 Value="Macro 11" />
								<MacroDisplayNames.11 Value="Macro 12" />
								<MacroDisplayNames.12 Value="Macro 13" />
								<MacroDisplayNames.13 Value="Macro 14" />
								<MacroDisplayNames.14 Value="Macro 15" />
								<MacroDisplayNames.15 Value="Macro 16" />
								<MacroDefaults.0 Value="-1" />
								<MacroDefaults.1 Value="-1" />
								<MacroDefaults.2 Value="-1" />
								<MacroDefaults.3 Value="-1" />
								<MacroDefaults.4 Value="-1" />
								<MacroDefaults.5 Value="-1" />
								<MacroDefaults.6 Value="-1" />
								<MacroDefaults.7 Value="-1" />
								<MacroDefaults.8 Value="-1" />
								<MacroDefaults.9 Value="-1" />
								<MacroDefaults.10 Value="-1" />
								<MacroDefaults.11 Value="-1" />
								<MacroDefaults.12 Value="-1" />
								<MacroDefaults.13 Value="-1" />
								<MacroDefaults.14 Value="-1" />
								<MacroDefaults.15 Value="-1" />
								<MacroAnnotations.0 Value="" />
								<MacroAnnotations.1 Value="" />
								<MacroAnnotations.2 Value="" />
								<MacroAnnotations.3 Value="" />
								<MacroAnnotations.4 Value="" />
								<MacroAnnotations.5 Value="" />
								<MacroAnnotations.6 Value="" />
								<MacroAnnotations.7 Value="" />
								<MacroAnnotations.8 Value="" />
								<MacroAnnotations.9 Value="" />
								<MacroAnnotations.10 Value="" />
								<MacroAnnotations.11 Value="" />
								<MacroAnnotations.12 Value="" />
								<MacroAnnotations.13 Value="" />
								<MacroAnnotations.14 Value="" />
								<MacroAnnotations.15 Value="" />
								<ForceDisplayGenericValue.0 Value="false" />
								<ForceDisplayGenericValue.1 Value="false" />
								<ForceDisplayGenericValue.2 Value="false" />
								<ForceDisplayGenericValue.3 Value="false" />
								<ForceDisplayGenericValue.4 Value="false" />
								<ForceDisplayGenericValue.5 Value="false" />
								<ForceDisplayGenericValue.6 Value="false" />
								<ForceDisplayGenericValue.7 Value="false" />
								<ForceDisplayGenericValue.8 Value="false" />
								<ForceDisplayGenericValue.9 Value="false" />
								<ForceDisplayGenericValue.10 Value="false" />
								<ForceDisplayGenericValue.11 Value="false" />
								<ForceDisplayGenericValue.12 Value="false" />
								<ForceDisplayGenericValue.13 Value="false" />
								<ForceDisplayGenericValue.14 Value="false" />
								<ForceDisplayGenericValue.15 Value="false" />
								<AreMacroControlsVisible Value="true" />
								<IsAutoSelectEnabled Value="false" />
								<ChainSelector>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="127" />
									</MidiControllerRange>
									<AutomationTarget Id="2243">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="2244">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</ChainSelector>
								<ChainSelectorRelativePosition Value="-1073741824" />
								<ViewsToRestoreWhenUnfolding Value="0" />
								<ReturnBranches />
								<BranchesSplitterProportion Value="0.5" />
								<ShowBranchesInSessionMixer Value="false" />
								<MacroColor.0 Value="13" />
								<MacroColor.1 Value="27" />
								<MacroColor.2 Value="27" />
								<MacroColor.3 Value="41" />
								<MacroColor.4 Value="55" />
								<MacroColor.5 Value="55" />
								<MacroColor.6 Value="69" />
								<MacroColor.7 Value="69" />
								<MacroColor.8 Value="-1" />
								<MacroColor.9 Value="-1" />
								<MacroColor.10 Value="-1" />
								<MacroColor.11 Value="-1" />
								<MacroColor.12 Value="-1" />
								<MacroColor.13 Value="-1" />
								<MacroColor.14 Value="-1" />
								<MacroColor.15 Value="-1" />
								<LockId Value="1001" />
								<LockSeal Value="973529826" />
								<ChainsListWrapper LomId="0" />
								<ReturnChainsListWrapper LomId="0" />
								<MacroVariations>
									<MacroSnapshots />
								</MacroVariations>
								<ExcludeMacroFromRandomization.0 Value="false" />
								<ExcludeMacroFromRandomization.1 Value="false" />
								<ExcludeMacroFromRandomization.2 Value="false" />
								<ExcludeMacroFromRandomization.3 Value="false" />
								<ExcludeMacroFromRandomization.4 Value="false" />
								<ExcludeMacroFromRandomization.5 Value="false" />
								<ExcludeMacroFromRandomization.6 Value="false" />
								<ExcludeMacroFromRandomization.7 Value="false" />
								<ExcludeMacroFromRandomization.8 Value="false" />
								<ExcludeMacroFromRandomization.9 Value="false" />
								<ExcludeMacroFromRandomization.10 Value="false" />
								<ExcludeMacroFromRandomization.11 Value="false" />
								<ExcludeMacroFromRandomization.12 Value="false" />
								<ExcludeMacroFromRandomization.13 Value="false" />
								<ExcludeMacroFromRandomization.14 Value="false" />
								<ExcludeMacroFromRandomization.15 Value="false" />
								<ExcludeMacroFromSnapshots.0 Value="false" />
								<ExcludeMacroFromSnapshots.1 Value="false" />
								<ExcludeMacroFromSnapshots.2 Value="false" />
								<ExcludeMacroFromSnapshots.3 Value="false" />
								<ExcludeMacroFromSnapshots.4 Value="false" />
								<ExcludeMacroFromSnapshots.5 Value="false" />
								<ExcludeMacroFromSnapshots.6 Value="false" />
								<ExcludeMacroFromSnapshots.7 Value="false" />
								<ExcludeMacroFromSnapshots.8 Value="false" />
								<ExcludeMacroFromSnapshots.9 Value="false" />
								<ExcludeMacroFromSnapshots.10 Value="false" />
								<ExcludeMacroFromSnapshots.11 Value="false" />
								<ExcludeMacroFromSnapshots.12 Value="false" />
								<ExcludeMacroFromSnapshots.13 Value="false" />
								<ExcludeMacroFromSnapshots.14 Value="false" />
								<ExcludeMacroFromSnapshots.15 Value="false" />
								<AreMacroVariationsControlsVisible Value="false" />
							</AudioEffectGroupDevice>
						</Devices>
						<SignalModulations />
					</DeviceChain>
				</DeviceChain>
				<IsTuned Value="true" />
			</AudioTrack>
			<ReturnTrack Id="2" SelectedToolPanel="7" SelectedTransformationName="" SelectedGeneratorName="">
				<LomId Value="0" />
				<LomIdView Value="0" />
				<IsContentSelectedInDocument Value="false" />
				<PreferredContentViewMode Value="0" />
				<TrackDelay>
					<Value Value="0" />
					<IsValueSampleBased Value="false" />
				</TrackDelay>
				<Name>
					<EffectiveName Value="A-Reverb" />
					<UserName Value="Reverb" />
					<Annotation Value="" />
					<MemorizedFirstClipName Value="" />
				</Name>
				<Color Value="27" />
				<AutomationEnvelopes>
					<Envelopes />
				</AutomationEnvelopes>
				<TrackGroupId Value="-1" />
				<TrackUnfolded Value="false" />
				<DevicesListWrapper LomId="0" />
				<ClipSlotsListWrapper LomId="0" />
				<ArrangementClipsListWrapper LomId="0" />
				<TakeLanesListWrapper LomId="0" />
				<ViewData Value='{"alternative_mode_locked": false, "push-instrument-selected-notes": [36], "push-note-repeat-rate": 0.5, "push-note-repeat-enabled": false}' />
				<TakeLanes>
					<TakeLanes />
					<AreTakeLanesFolded Value="true" />
				</TakeLanes>
				<LinkedTrackGroupId Value="-1" />
				<DeviceChain>
					<AutomationLanes>
						<AutomationLanes>
							<AutomationLane Id="0">
								<SelectedDevice Value="1" />
								<SelectedEnvelope Value="27" />
								<IsContentSelectedInDocument Value="false" />
								<LaneHeight Value="17" />
							</AutomationLane>
						</AutomationLanes>
						<AreAdditionalAutomationLanesFolded Value="false" />
					</AutomationLanes>
					<ClipEnvelopeChooserViewState>
						<SelectedDevice Value="0" />
						<SelectedEnvelope Value="0" />
						<PreferModulationVisible Value="false" />
					</ClipEnvelopeChooserViewState>
					<AudioInputRouting>
						<Target Value="AudioIn/External/S0" />
						<UpperDisplayString Value="Ext. In" />
						<LowerDisplayString Value="1/2" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</AudioInputRouting>
					<MidiInputRouting>
						<Target Value="MidiIn/External.All/-1" />
						<UpperDisplayString Value="Ext: All Ins" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</MidiInputRouting>
					<AudioOutputRouting>
						<Target Value="AudioOut/Main" />
						<UpperDisplayString Value="Master" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</AudioOutputRouting>
					<MidiOutputRouting>
						<Target Value="MidiOut/None" />
						<UpperDisplayString Value="None" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</MidiOutputRouting>
					<Mixer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="812">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10505" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="false" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<Sends>
							<TrackSendHolder Id="0">
								<Send>
									<LomId Value="0" />
									<Manual Value="0.00031622799" />
									<MidiControllerRange>
										<Min Value="0.00031622799" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="813">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="445">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Send>
								<EnabledByUser Value="false" />
							</TrackSendHolder>
							<TrackSendHolder Id="2">
								<Send>
									<LomId Value="0" />
									<Manual Value="0.0003162277571" />
									<MidiControllerRange>
										<Min Value="0.0003162277571" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1574">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1575">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Send>
								<EnabledByUser Value="false" />
							</TrackSendHolder>
						</Sends>
						<Speaker>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="815">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</Speaker>
						<SoloSink Value="false" />
						<PanMode Value="0" />
						<Pan>
							<LomId Value="0" />
							<Manual Value="0" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="816">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="436">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</Pan>
						<SplitStereoPanL>
							<LomId Value="0" />
							<Manual Value="-1" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="817">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="818">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</SplitStereoPanL>
						<SplitStereoPanR>
							<LomId Value="0" />
							<Manual Value="1" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="819">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="820">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</SplitStereoPanR>
						<Volume>
							<LomId Value="0" />
							<Manual Value="1" />
							<MidiControllerRange>
								<Min Value="0.00031622799" />
								<Max Value="1.99526203" />
							</MidiControllerRange>
							<AutomationTarget Id="821">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="437">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</Volume>
						<ViewStateSessionTrackWidth Value="74" />
						<CrossFadeState>
							<LomId Value="0" />
							<Manual Value="1" />
							<AutomationTarget Id="822">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiControllerRange>
								<Min Value="0" />
								<Max Value="2" />
							</MidiControllerRange>
						</CrossFadeState>
						<SendsListWrapper LomId="0" />
					</Mixer>
					<DeviceChain>
						<Devices>
							<Reverb Id="0">
								<LomId Value="0" />
								<LomIdView Value="0" />
								<IsExpanded Value="true" />
								<BreakoutIsExpanded Value="false" />
								<On>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1435">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</On>
								<ModulationSourceCount Value="0" />
								<ParametersListWrapper LomId="0" />
								<Pointee Id="10506" />
								<LastSelectedTimeableIndex Value="27" />
								<LastSelectedClipEnvelopeIndex Value="0" />
								<LastPresetRef>
									<Value>
										</Value>
								</LastPresetRef>
								<LockedScripts />
								<IsFolded Value="false" />
								<ShouldShowPresetName Value="true" />
								<UserName Value="Long Reverb" />
								<Annotation Value="Created by: Philipp Matalla" />
								<SourceContext>
									<Value />
								</SourceContext>
								<MpePitchBendUsesTuning Value="true" />
								<ViewData Value="{}" />
								<OverwriteProtectionNumber Value="3075" />
								<PreDelay>
									<LomId Value="0" />
									<Manual Value="34.1527901" />
									<MidiControllerRange>
										<Min Value="0.5" />
										<Max Value="250" />
									</MidiControllerRange>
									<AutomationTarget Id="1436">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1437">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</PreDelay>
								<BandHighOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1438">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</BandHighOn>
								<BandLowOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1439">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</BandLowOn>
								<BandFreq>
									<LomId Value="0" />
									<Manual Value="789.290344" />
									<MidiControllerRange>
										<Min Value="50" />
										<Max Value="18000" />
									</MidiControllerRange>
									<AutomationTarget Id="1440">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1441">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</BandFreq>
								<BandWidth>
									<LomId Value="0" />
									<Manual Value="6.875" />
									<MidiControllerRange>
										<Min Value="0.5" />
										<Max Value="9" />
									</MidiControllerRange>
									<AutomationTarget Id="1442">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1443">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</BandWidth>
								<SpinOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1444">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</SpinOn>
								<EarlyReflectModFreq>
									<LomId Value="0" />
									<Manual Value="0.1359131485" />
									<MidiControllerRange>
										<Min Value="0.07400000095" />
										<Max Value="1.29999995" />
									</MidiControllerRange>
									<AutomationTarget Id="1445">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1446">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</EarlyReflectModFreq>
								<EarlyReflectModDepth>
									<LomId Value="0" />
									<Manual Value="7.42618656" />
									<MidiControllerRange>
										<Min Value="2" />
										<Max Value="55" />
									</MidiControllerRange>
									<AutomationTarget Id="1447">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1448">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</EarlyReflectModDepth>
								<DiffuseDelay>
									<LomId Value="0" />
									<Manual Value="0.1666666716" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1449">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1450">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DiffuseDelay>
								<ShelfHighOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1451">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</ShelfHighOn>
								<HighFilterType>
									<LomId Value="0" />
									<Manual Value="0" />
									<AutomationTarget Id="10827">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="1" />
									</MidiControllerRange>
								</HighFilterType>
								<ShelfHiFreq>
									<LomId Value="0" />
									<Manual Value="2213.31079" />
									<MidiControllerRange>
										<Min Value="20" />
										<Max Value="16000" />
									</MidiControllerRange>
									<AutomationTarget Id="1452">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1453">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</ShelfHiFreq>
								<ShelfHiGain>
									<LomId Value="0" />
									<Manual Value="0.462500006" />
									<MidiControllerRange>
										<Min Value="0.200000003" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1454">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1455">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</ShelfHiGain>
								<ShelfLowOn>
									<LomId Value="0" />
									<Manual Value="false" />
									<AutomationTarget Id="1456">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</ShelfLowOn>
								<ShelfLoFreq>
									<LomId Value="0" />
									<Manual Value="90" />
									<MidiControllerRange>
										<Min Value="20" />
										<Max Value="15000" />
									</MidiControllerRange>
									<AutomationTarget Id="1457">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1458">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</ShelfLoFreq>
								<ShelfLoGain>
									<LomId Value="0" />
									<Manual Value="0.75" />
									<MidiControllerRange>
										<Min Value="0.200000003" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1459">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1460">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</ShelfLoGain>
								<ChorusOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1461">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</ChorusOn>
								<SizeModFreq>
									<LomId Value="0" />
									<Manual Value="0.04568705708" />
									<MidiControllerRange>
										<Min Value="0.009999999776" />
										<Max Value="8" />
									</MidiControllerRange>
									<AutomationTarget Id="1462">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1463">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</SizeModFreq>
								<SizeModDepth>
									<LomId Value="0" />
									<Manual Value="0.01866585575" />
									<MidiControllerRange>
										<Min Value="0.009999999776" />
										<Max Value="4" />
									</MidiControllerRange>
									<AutomationTarget Id="1464">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1465">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</SizeModDepth>
								<DecayTime>
									<LomId Value="0" />
									<Manual Value="5408.98438" />
									<MidiControllerRange>
										<Min Value="200" />
										<Max Value="60000" />
									</MidiControllerRange>
									<AutomationTarget Id="1466">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1467">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DecayTime>
								<AllPassGain>
									<LomId Value="0" />
									<Manual Value="0.6000000238" />
									<MidiControllerRange>
										<Min Value="0.001000000047" />
										<Max Value="0.9599999785" />
									</MidiControllerRange>
									<AutomationTarget Id="1468">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1469">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</AllPassGain>
								<AllPassSize>
									<LomId Value="0" />
									<Manual Value="0.8664062619" />
									<MidiControllerRange>
										<Min Value="0.05000000075" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1470">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1471">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</AllPassSize>
								<FreezeOn>
									<LomId Value="0" />
									<Manual Value="false" />
									<AutomationTarget Id="1472">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</FreezeOn>
								<FlatOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1473">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</FlatOn>
								<CutOn>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1474">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</CutOn>
								<RoomSize>
									<LomId Value="0" />
									<Manual Value="33.7454262" />
									<MidiControllerRange>
										<Min Value="0.2220000029" />
										<Max Value="500" />
									</MidiControllerRange>
									<AutomationTarget Id="1475">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1476">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</RoomSize>
								<SizeSmoothing>
									<LomId Value="0" />
									<Manual Value="2" />
									<AutomationTarget Id="10828">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="2" />
									</MidiControllerRange>
								</SizeSmoothing>
								<StereoSeparation>
									<LomId Value="0" />
									<Manual Value="115.238098" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="120" />
									</MidiControllerRange>
									<AutomationTarget Id="1477">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1478">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</StereoSeparation>
								<RoomType>
									<LomId Value="0" />
									<Manual Value="3" />
									<AutomationTarget Id="1479">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="3" />
									</MidiControllerRange>
								</RoomType>
								<MixReflect>
									<LomId Value="0" />
									<Manual Value="1.2934072" />
									<MidiControllerRange>
										<Min Value="0.02999999933" />
										<Max Value="1.99530005" />
									</MidiControllerRange>
									<AutomationTarget Id="1480">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1481">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MixReflect>
								<MixDiffuse>
									<LomId Value="0" />
									<Manual Value="1.09063816" />
									<MidiControllerRange>
										<Min Value="0.02999999933" />
										<Max Value="1.99530005" />
									</MidiControllerRange>
									<AutomationTarget Id="1482">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1483">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MixDiffuse>
								<MixDirect>
									<LomId Value="0" />
									<Manual Value="1" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1484">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1485">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</MixDirect>
								<StereoSeparationOnDrySignal Value="false" />
							</Reverb>
						</Devices>
						<SignalModulations />
					</DeviceChain>
					<FreezeSequencer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="823">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10507" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="false" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<ClipSlotList />
						<MonitoringEnum Value="1" />
						<KeepRecordMonitoringLatency Value="true" />
						<Sample>
							<ArrangerAutomation>
								<Events />
								<AutomationTransformViewState>
									<IsTransformPending Value="false" />
									<TimeAndValueTransforms />
								</AutomationTransformViewState>
							</ArrangerAutomation>
						</Sample>
						<VolumeModulationTarget Id="438">
							<LockEnvelope Value="0" />
						</VolumeModulationTarget>
						<TranspositionModulationTarget Id="439">
							<LockEnvelope Value="0" />
						</TranspositionModulationTarget>
						<TransientEnvelopeModulationTarget Id="10877">
							<LockEnvelope Value="0" />
						</TransientEnvelopeModulationTarget>
						<GrainSizeModulationTarget Id="440">
							<LockEnvelope Value="0" />
						</GrainSizeModulationTarget>
						<FluxModulationTarget Id="441">
							<LockEnvelope Value="0" />
						</FluxModulationTarget>
						<SampleOffsetModulationTarget Id="442">
							<LockEnvelope Value="0" />
						</SampleOffsetModulationTarget>
						<ComplexProFormantsModulationTarget Id="10878">
							<LockEnvelope Value="0" />
						</ComplexProFormantsModulationTarget>
						<ComplexProEnvelopeModulationTarget Id="10879">
							<LockEnvelope Value="0" />
						</ComplexProEnvelopeModulationTarget>
						<PitchViewScrollPosition Value="-1073741824" />
						<SampleOffsetModulationScrollPosition Value="-1073741824" />
						<Recorder>
							<IsArmed Value="false" />
							<TakeCounter Value="1" />
						</Recorder>
					</FreezeSequencer>
				</DeviceChain>
			</ReturnTrack>
			<ReturnTrack Id="11" SelectedToolPanel="7" SelectedTransformationName="" SelectedGeneratorName="">
				<LomId Value="0" />
				<LomIdView Value="0" />
				<IsContentSelectedInDocument Value="false" />
				<PreferredContentViewMode Value="0" />
				<TrackDelay>
					<Value Value="0" />
					<IsValueSampleBased Value="false" />
				</TrackDelay>
				<Name>
					<EffectiveName Value="B-Delay" />
					<UserName Value="Delay" />
					<Annotation Value="" />
					<MemorizedFirstClipName Value="" />
				</Name>
				<Color Value="27" />
				<AutomationEnvelopes>
					<Envelopes />
				</AutomationEnvelopes>
				<TrackGroupId Value="-1" />
				<TrackUnfolded Value="false" />
				<DevicesListWrapper LomId="0" />
				<ClipSlotsListWrapper LomId="0" />
				<ArrangementClipsListWrapper LomId="0" />
				<TakeLanesListWrapper LomId="0" />
				<ViewData Value='{"alternative_mode_locked": false, "push-instrument-selected-notes": [36], "push-note-repeat-rate": 0.5, "push-note-repeat-enabled": false}' />
				<TakeLanes>
					<TakeLanes />
					<AreTakeLanesFolded Value="true" />
				</TakeLanes>
				<LinkedTrackGroupId Value="-1" />
				<DeviceChain>
					<AutomationLanes>
						<AutomationLanes>
							<AutomationLane Id="0">
								<SelectedDevice Value="0" />
								<SelectedEnvelope Value="0" />
								<IsContentSelectedInDocument Value="false" />
								<LaneHeight Value="17" />
							</AutomationLane>
						</AutomationLanes>
						<AreAdditionalAutomationLanesFolded Value="false" />
					</AutomationLanes>
					<ClipEnvelopeChooserViewState>
						<SelectedDevice Value="0" />
						<SelectedEnvelope Value="0" />
						<PreferModulationVisible Value="false" />
					</ClipEnvelopeChooserViewState>
					<AudioInputRouting>
						<Target Value="AudioIn/External/S0" />
						<UpperDisplayString Value="Ext. In" />
						<LowerDisplayString Value="1/2" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</AudioInputRouting>
					<MidiInputRouting>
						<Target Value="MidiIn/External.All/-1" />
						<UpperDisplayString Value="Ext: All Ins" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</MidiInputRouting>
					<AudioOutputRouting>
						<Target Value="AudioOut/Main" />
						<UpperDisplayString Value="Master" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</AudioOutputRouting>
					<MidiOutputRouting>
						<Target Value="MidiOut/None" />
						<UpperDisplayString Value="None" />
						<LowerDisplayString Value="" />
						<MpeSettings>
							<ZoneType Value="0" />
							<FirstNoteChannel Value="1" />
							<LastNoteChannel Value="15" />
						</MpeSettings>
						<MpePitchBendUsesTuning Value="true" />
					</MidiOutputRouting>
					<Mixer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="1537">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10508" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="true" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<Sends>
							<TrackSendHolder Id="0">
								<Send>
									<LomId Value="0" />
									<Manual Value="0.0003162277571" />
									<MidiControllerRange>
										<Min Value="0.0003162277571" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1538">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1539">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Send>
								<EnabledByUser Value="false" />
							</TrackSendHolder>
							<TrackSendHolder Id="2">
								<Send>
									<LomId Value="0" />
									<Manual Value="0.0003162277571" />
									<MidiControllerRange>
										<Min Value="0.0003162277571" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1578">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1579">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Send>
								<EnabledByUser Value="false" />
							</TrackSendHolder>
						</Sends>
						<Speaker>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="1542">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</Speaker>
						<SoloSink Value="false" />
						<PanMode Value="0" />
						<Pan>
							<LomId Value="0" />
							<Manual Value="0" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="1543">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="1544">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</Pan>
						<SplitStereoPanL>
							<LomId Value="0" />
							<Manual Value="-1" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="1545">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="1546">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</SplitStereoPanL>
						<SplitStereoPanR>
							<LomId Value="0" />
							<Manual Value="1" />
							<MidiControllerRange>
								<Min Value="-1" />
								<Max Value="1" />
							</MidiControllerRange>
							<AutomationTarget Id="1547">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="1548">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</SplitStereoPanR>
						<Volume>
							<LomId Value="0" />
							<Manual Value="1" />
							<MidiControllerRange>
								<Min Value="0.0003162277571" />
								<Max Value="1.99526238" />
							</MidiControllerRange>
							<AutomationTarget Id="1549">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<ModulationTarget Id="1550">
								<LockEnvelope Value="0" />
							</ModulationTarget>
						</Volume>
						<ViewStateSessionTrackWidth Value="74" />
						<CrossFadeState>
							<LomId Value="0" />
							<Manual Value="1" />
							<AutomationTarget Id="1551">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiControllerRange>
								<Min Value="0" />
								<Max Value="2" />
							</MidiControllerRange>
						</CrossFadeState>
						<SendsListWrapper LomId="0" />
					</Mixer>
					<DeviceChain>
						<Devices>
							<Delay Id="0">
								<LomId Value="0" />
								<LomIdView Value="0" />
								<IsExpanded Value="true" />
								<BreakoutIsExpanded Value="false" />
								<On>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1580">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</On>
								<ModulationSourceCount Value="0" />
								<ParametersListWrapper LomId="0" />
								<Pointee Id="10509" />
								<LastSelectedTimeableIndex Value="0" />
								<LastSelectedClipEnvelopeIndex Value="0" />
								<LastPresetRef>
									<Value>
										</Value>
								</LastPresetRef>
								<LockedScripts />
								<IsFolded Value="false" />
								<ShouldShowPresetName Value="true" />
								<UserName Value="Delay" />
								<Annotation Value="" />
								<SourceContext>
									<Value />
								</SourceContext>
								<MpePitchBendUsesTuning Value="true" />
								<ViewData Value="{}" />
								<OverwriteProtectionNumber Value="3075" />
								<DelayLine_SmoothingMode>
									<LomId Value="0" />
									<Manual Value="0" />
									<AutomationTarget Id="1581">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="2" />
									</MidiControllerRange>
								</DelayLine_SmoothingMode>
								<DelayLine_Link>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1582">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</DelayLine_Link>
								<DelayLine_PingPong>
									<LomId Value="0" />
									<Manual Value="false" />
									<AutomationTarget Id="1583">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</DelayLine_PingPong>
								<DelayLine_SyncL>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1584">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</DelayLine_SyncL>
								<DelayLine_SyncR>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1585">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</DelayLine_SyncR>
								<DelayLine_TimeL>
									<LomId Value="0" />
									<Manual Value="0.3749999404" />
									<MidiControllerRange>
										<Min Value="0.001000000047" />
										<Max Value="5" />
									</MidiControllerRange>
									<AutomationTarget Id="1586">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1587">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_TimeL>
								<DelayLine_TimeR>
									<LomId Value="0" />
									<Manual Value="0.3749999404" />
									<MidiControllerRange>
										<Min Value="0.001000000047" />
										<Max Value="5" />
									</MidiControllerRange>
									<AutomationTarget Id="1588">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1589">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_TimeR>
								<DelayLine_SimpleDelayTimeL>
									<LomId Value="0" />
									<Manual Value="100" />
									<MidiControllerRange>
										<Min Value="1" />
										<Max Value="300" />
									</MidiControllerRange>
									<AutomationTarget Id="1590">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1591">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_SimpleDelayTimeL>
								<DelayLine_SimpleDelayTimeR>
									<LomId Value="0" />
									<Manual Value="100" />
									<MidiControllerRange>
										<Min Value="1" />
										<Max Value="300" />
									</MidiControllerRange>
									<AutomationTarget Id="1592">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1593">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_SimpleDelayTimeR>
								<DelayLine_PingPongDelayTimeL>
									<LomId Value="0" />
									<Manual Value="1" />
									<MidiControllerRange>
										<Min Value="1" />
										<Max Value="999" />
									</MidiControllerRange>
									<AutomationTarget Id="1594">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1595">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_PingPongDelayTimeL>
								<DelayLine_PingPongDelayTimeR>
									<LomId Value="0" />
									<Manual Value="1" />
									<MidiControllerRange>
										<Min Value="1" />
										<Max Value="999" />
									</MidiControllerRange>
									<AutomationTarget Id="1596">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1597">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_PingPongDelayTimeR>
								<DelayLine_SyncedSixteenthL>
									<LomId Value="0" />
									<Manual Value="1" />
									<AutomationTarget Id="1598">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="7" />
									</MidiControllerRange>
								</DelayLine_SyncedSixteenthL>
								<DelayLine_SyncedSixteenthR>
									<LomId Value="0" />
									<Manual Value="3" />
									<AutomationTarget Id="1599">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="7" />
									</MidiControllerRange>
								</DelayLine_SyncedSixteenthR>
								<DelayLine_OffsetL>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="-0.3330000043" />
										<Max Value="0.3330000043" />
									</MidiControllerRange>
									<AutomationTarget Id="1600">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1601">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_OffsetL>
								<DelayLine_OffsetR>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="-0.3330000043" />
										<Max Value="0.3330000043" />
									</MidiControllerRange>
									<AutomationTarget Id="1602">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1603">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DelayLine_OffsetR>
								<DelayLine_CompatibilityMode Value="0" />
								<Feedback>
									<LomId Value="0" />
									<Manual Value="0.2789682746" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="0.9499999881" />
									</MidiControllerRange>
									<AutomationTarget Id="1604">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1605">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Feedback>
								<Freeze>
									<LomId Value="0" />
									<Manual Value="false" />
									<AutomationTarget Id="1606">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</Freeze>
								<Filter_On>
									<LomId Value="0" />
									<Manual Value="true" />
									<AutomationTarget Id="1607">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<MidiCCOnOffThresholds>
										<Min Value="64" />
										<Max Value="127" />
									</MidiCCOnOffThresholds>
								</Filter_On>
								<Filter_Frequency>
									<LomId Value="0" />
									<Manual Value="999.999878" />
									<MidiControllerRange>
										<Min Value="49.9999962" />
										<Max Value="18000.0059" />
									</MidiControllerRange>
									<AutomationTarget Id="1608">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1609">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Filter_Frequency>
								<Filter_Bandwidth>
									<LomId Value="0" />
									<Manual Value="8" />
									<MidiControllerRange>
										<Min Value="0.5" />
										<Max Value="9" />
									</MidiControllerRange>
									<AutomationTarget Id="1610">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1611">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Filter_Bandwidth>
								<Modulation_Frequency>
									<LomId Value="0" />
									<Manual Value="0.5" />
									<MidiControllerRange>
										<Min Value="0.01000000071" />
										<Max Value="39.9999962" />
									</MidiControllerRange>
									<AutomationTarget Id="1612">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1613">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Modulation_Frequency>
								<Modulation_AmountTime>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1614">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1615">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Modulation_AmountTime>
								<Modulation_AmountFilter>
									<LomId Value="0" />
									<Manual Value="0" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1616">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1617">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</Modulation_AmountFilter>
								<DryWet>
									<LomId Value="0" />
									<Manual Value="1" />
									<MidiControllerRange>
										<Min Value="0" />
										<Max Value="1" />
									</MidiControllerRange>
									<AutomationTarget Id="1618">
										<LockEnvelope Value="0" />
									</AutomationTarget>
									<ModulationTarget Id="1619">
										<LockEnvelope Value="0" />
									</ModulationTarget>
								</DryWet>
								<DryWetMode Value="1" />
								<EcoProcessing Value="false" />
							</Delay>
						</Devices>
						<SignalModulations />
					</DeviceChain>
					<FreezeSequencer>
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="1552">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10510" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="true" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<ClipSlotList />
						<MonitoringEnum Value="1" />
						<KeepRecordMonitoringLatency Value="true" />
						<Sample>
							<ArrangerAutomation>
								<Events />
								<AutomationTransformViewState>
									<IsTransformPending Value="false" />
									<TimeAndValueTransforms />
								</AutomationTransformViewState>
							</ArrangerAutomation>
						</Sample>
						<VolumeModulationTarget Id="1553">
							<LockEnvelope Value="0" />
						</VolumeModulationTarget>
						<TranspositionModulationTarget Id="1554">
							<LockEnvelope Value="0" />
						</TranspositionModulationTarget>
						<TransientEnvelopeModulationTarget Id="10880">
							<LockEnvelope Value="0" />
						</TransientEnvelopeModulationTarget>
						<GrainSizeModulationTarget Id="1555">
							<LockEnvelope Value="0" />
						</GrainSizeModulationTarget>
						<FluxModulationTarget Id="1556">
							<LockEnvelope Value="0" />
						</FluxModulationTarget>
						<SampleOffsetModulationTarget Id="1557">
							<LockEnvelope Value="0" />
						</SampleOffsetModulationTarget>
						<ComplexProFormantsModulationTarget Id="10881">
							<LockEnvelope Value="0" />
						</ComplexProFormantsModulationTarget>
						<ComplexProEnvelopeModulationTarget Id="10882">
							<LockEnvelope Value="0" />
						</ComplexProEnvelopeModulationTarget>
						<PitchViewScrollPosition Value="-1073741824" />
						<SampleOffsetModulationScrollPosition Value="-1073741824" />
						<Recorder>
							<IsArmed Value="false" />
							<TakeCounter Value="1" />
						</Recorder>
					</FreezeSequencer>
				</DeviceChain>
			</ReturnTrack>
		</Tracks>
		<MainTrack SelectedToolPanel="7" SelectedTransformationName="" SelectedGeneratorName="">
			<LomId Value="0" />
			<LomIdView Value="0" />
			<IsContentSelectedInDocument Value="false" />
			<PreferredContentViewMode Value="0" />
			<TrackDelay>
				<Value Value="0" />
				<IsValueSampleBased Value="false" />
			</TrackDelay>
			<Name>
				<EffectiveName Value="Main" />
				<UserName Value="" />
				<Annotation Value="" />
				<MemorizedFirstClipName Value="" />
			</Name>
			<Color Value="13" />
			<AutomationEnvelopes>
				<Envelopes>
					<AutomationEnvelope Id="0">
						<EnvelopeTarget>
							<PointeeId Value="846" />
						</EnvelopeTarget>
						<Automation>
							<Events>
								<EnumEvent Id="0" Time="-63072000" Value="201" />
							</Events>
							<AutomationTransformViewState>
								<IsTransformPending Value="false" />
								<TimeAndValueTransforms />
							</AutomationTransformViewState>
						</Automation>
					</AutomationEnvelope>
					<AutomationEnvelope Id="1">
						<EnvelopeTarget>
							<PointeeId Value="845" />
						</EnvelopeTarget>
						<Automation>
							<Events>
								<FloatEvent Id="0" Time="-63072000" Value="120" />
							</Events>
							<AutomationTransformViewState>
								<IsTransformPending Value="false" />
								<TimeAndValueTransforms />
							</AutomationTransformViewState>
						</Automation>
					</AutomationEnvelope>
				</Envelopes>
			</AutomationEnvelopes>
			<TrackGroupId Value="-1" />
			<TrackUnfolded Value="false" />
			<DevicesListWrapper LomId="0" />
			<ClipSlotsListWrapper LomId="0" />
			<ArrangementClipsListWrapper LomId="0" />
			<TakeLanesListWrapper LomId="0" />
			<ViewData Value='{"alternative_mode_locked": false, "push-instrument-selected-notes": [36], "push-note-repeat-rate": 0.5, "push-note-repeat-enabled": false}' />
			<TakeLanes>
				<TakeLanes />
				<AreTakeLanesFolded Value="true" />
			</TakeLanes>
			<LinkedTrackGroupId Value="-1" />
			<DeviceChain>
				<AutomationLanes>
					<AutomationLanes>
						<AutomationLane Id="0">
							<SelectedDevice Value="2" />
							<SelectedEnvelope Value="0" />
							<IsContentSelectedInDocument Value="false" />
							<LaneHeight Value="17" />
						</AutomationLane>
					</AutomationLanes>
					<AreAdditionalAutomationLanesFolded Value="false" />
				</AutomationLanes>
				<ClipEnvelopeChooserViewState>
					<SelectedDevice Value="0" />
					<SelectedEnvelope Value="0" />
					<PreferModulationVisible Value="false" />
				</ClipEnvelopeChooserViewState>
				<AudioInputRouting>
					<Target Value="AudioOut/External/S0" />
					<UpperDisplayString Value="Ext. Out" />
					<LowerDisplayString Value="1/2" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</AudioInputRouting>
				<MidiInputRouting>
					<Target Value="MidiIn/External.All/-1" />
					<UpperDisplayString Value="Ext: All Ins" />
					<LowerDisplayString Value="" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</MidiInputRouting>
				<AudioOutputRouting>
					<Target Value="AudioOut/External/S0" />
					<UpperDisplayString Value="Ext. Out" />
					<LowerDisplayString Value="1/2" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</AudioOutputRouting>
				<MidiOutputRouting>
					<Target Value="MidiOut/None" />
					<UpperDisplayString Value="None" />
					<LowerDisplayString Value="" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</MidiOutputRouting>
				<Mixer>
					<LomId Value="0" />
					<LomIdView Value="0" />
					<IsExpanded Value="true" />
					<BreakoutIsExpanded Value="false" />
					<On>
						<LomId Value="0" />
						<Manual Value="true" />
						<AutomationTarget Id="836">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiCCOnOffThresholds>
							<Min Value="64" />
							<Max Value="127" />
						</MidiCCOnOffThresholds>
					</On>
					<ModulationSourceCount Value="0" />
					<ParametersListWrapper LomId="0" />
					<Pointee Id="10511" />
					<LastSelectedTimeableIndex Value="0" />
					<LastSelectedClipEnvelopeIndex Value="0" />
					<LastPresetRef>
						<Value />
					</LastPresetRef>
					<LockedScripts />
					<IsFolded Value="false" />
					<ShouldShowPresetName Value="false" />
					<UserName Value="" />
					<Annotation Value="" />
					<SourceContext>
						<Value />
					</SourceContext>
					<MpePitchBendUsesTuning Value="true" />
					<ViewData Value="{}" />
					<Sends />
					<Speaker>
						<LomId Value="0" />
						<Manual Value="true" />
						<AutomationTarget Id="837">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiCCOnOffThresholds>
							<Min Value="64" />
							<Max Value="127" />
						</MidiCCOnOffThresholds>
					</Speaker>
					<SoloSink Value="false" />
					<PanMode Value="0" />
					<Pan>
						<LomId Value="0" />
						<Manual Value="0" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="838">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="134">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</Pan>
					<SplitStereoPanL>
						<LomId Value="0" />
						<Manual Value="-1" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="839">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="840">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</SplitStereoPanL>
					<SplitStereoPanR>
						<LomId Value="0" />
						<Manual Value="1" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="841">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="842">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</SplitStereoPanR>
					<Volume>
						<LomId Value="0" />
						<Manual Value="1" />
						<MidiControllerRange>
							<Min Value="0.00031622799" />
							<Max Value="1.99526203" />
						</MidiControllerRange>
						<AutomationTarget Id="843">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="135">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</Volume>
					<ViewStateSessionTrackWidth Value="84" />
					<CrossFadeState>
						<LomId Value="0" />
						<Manual Value="1" />
						<AutomationTarget Id="844">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiControllerRange>
							<Min Value="0" />
							<Max Value="2" />
						</MidiControllerRange>
					</CrossFadeState>
					<SendsListWrapper LomId="0" />
					<Tempo>
						<LomId Value="0" />
						<Manual Value="120" />
						<MidiControllerRange>
							<Min Value="60" />
							<Max Value="200" />
						</MidiControllerRange>
						<AutomationTarget Id="845">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="136">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</Tempo>
					<TimeSignature>
						<LomId Value="0" />
						<Manual Value="201" />
						<AutomationTarget Id="846">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiControllerRange>
							<Min Value="0" />
							<Max Value="494" />
						</MidiControllerRange>
					</TimeSignature>
					<GlobalGrooveAmount>
						<LomId Value="0" />
						<Manual Value="100" />
						<MidiControllerRange>
							<Min Value="0" />
							<Max Value="131.25" />
						</MidiControllerRange>
						<AutomationTarget Id="847">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="137">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</GlobalGrooveAmount>
					<CrossFade>
						<LomId Value="0" />
						<Manual Value="0" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="848">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="138">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</CrossFade>
					<TempoAutomationViewBottom Value="60" />
					<TempoAutomationViewTop Value="200" />
				</Mixer>
				<FreezeSequencer>
					<AudioSequencer Id="0">
						<LomId Value="0" />
						<LomIdView Value="0" />
						<IsExpanded Value="true" />
						<BreakoutIsExpanded Value="false" />
						<On>
							<LomId Value="0" />
							<Manual Value="true" />
							<AutomationTarget Id="849">
								<LockEnvelope Value="0" />
							</AutomationTarget>
							<MidiCCOnOffThresholds>
								<Min Value="64" />
								<Max Value="127" />
							</MidiCCOnOffThresholds>
						</On>
						<ModulationSourceCount Value="0" />
						<ParametersListWrapper LomId="0" />
						<Pointee Id="10512" />
						<LastSelectedTimeableIndex Value="0" />
						<LastSelectedClipEnvelopeIndex Value="0" />
						<LastPresetRef>
							<Value />
						</LastPresetRef>
						<LockedScripts />
						<IsFolded Value="false" />
						<ShouldShowPresetName Value="false" />
						<UserName Value="" />
						<Annotation Value="" />
						<SourceContext>
							<Value />
						</SourceContext>
						<MpePitchBendUsesTuning Value="true" />
						<ViewData Value="{}" />
						<ClipSlotList>
							<ClipSlot Id="0">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="1">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="2">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="3">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="4">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="5">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="6">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
							<ClipSlot Id="7">
								<LomId Value="0" />
								<ClipSlot>
									<Value />
								</ClipSlot>
								<HasStop Value="true" />
								<NeedRefreeze Value="true" />
							</ClipSlot>
						</ClipSlotList>
						<MonitoringEnum Value="1" />
						<KeepRecordMonitoringLatency Value="true" />
						<Sample>
							<ArrangerAutomation>
								<Events />
								<AutomationTransformViewState>
									<IsTransformPending Value="false" />
									<TimeAndValueTransforms />
								</AutomationTransformViewState>
							</ArrangerAutomation>
						</Sample>
						<VolumeModulationTarget Id="139">
							<LockEnvelope Value="0" />
						</VolumeModulationTarget>
						<TranspositionModulationTarget Id="140">
							<LockEnvelope Value="0" />
						</TranspositionModulationTarget>
						<TransientEnvelopeModulationTarget Id="10883">
							<LockEnvelope Value="0" />
						</TransientEnvelopeModulationTarget>
						<GrainSizeModulationTarget Id="141">
							<LockEnvelope Value="0" />
						</GrainSizeModulationTarget>
						<FluxModulationTarget Id="142">
							<LockEnvelope Value="0" />
						</FluxModulationTarget>
						<SampleOffsetModulationTarget Id="143">
							<LockEnvelope Value="0" />
						</SampleOffsetModulationTarget>
						<ComplexProFormantsModulationTarget Id="10884">
							<LockEnvelope Value="0" />
						</ComplexProFormantsModulationTarget>
						<ComplexProEnvelopeModulationTarget Id="10885">
							<LockEnvelope Value="0" />
						</ComplexProEnvelopeModulationTarget>
						<PitchViewScrollPosition Value="-1073741824" />
						<SampleOffsetModulationScrollPosition Value="-1073741824" />
						<Recorder>
							<IsArmed Value="false" />
							<TakeCounter Value="1" />
						</Recorder>
					</AudioSequencer>
				</FreezeSequencer>
				<DeviceChain>
					<Devices>
						<StereoGain Id="0">
							<LomId Value="0" />
							<LomIdView Value="0" />
							<IsExpanded Value="true" />
							<BreakoutIsExpanded Value="false" />
							<On>
								<LomId Value="0" />
								<Manual Value="true" />
								<AutomationTarget Id="1620">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</On>
							<ModulationSourceCount Value="0" />
							<ParametersListWrapper LomId="0" />
							<Pointee Id="10513" />
							<LastSelectedTimeableIndex Value="6" />
							<LastSelectedClipEnvelopeIndex Value="0" />
							<LastPresetRef>
								<Value>
									</Value>
							</LastPresetRef>
							<LockedScripts />
							<IsFolded Value="false" />
							<ShouldShowPresetName Value="true" />
							<UserName Value="" />
							<Annotation Value="" />
							<SourceContext>
								<Value>
									<BranchSourceContext Id="0">
										<OriginalFileRef>
											<FileRef Id="0">
												<RelativePathType Value="5" />
												<RelativePath Value="Devices/Audio Effects/Utility" />
												<Path Value="/Applications/Ableton Live 12 Suite.app/Contents/App-Resources/Core Library/Devices/Audio Effects/Utility" />
												<Type Value="2" />
												<LivePackName Value="Core Library" />
												<LivePackId Value="www.ableton.com/0" />
												<OriginalFileSize Value="0" />
												<OriginalCrc Value="0" />
												<SourceHint Value="" />
											</FileRef>
										</OriginalFileRef>
										<BrowserContentPath Value="query:AudioFx#Utility" />
										<LocalFiltersJson Value="" />
										<PresetRef>
											<AbletonDefaultPresetRef Id="0" /></PresetRef>
										<BranchDeviceId Value="device:ableton:audiofx:StereoGain" />
									</BranchSourceContext>
								</Value>
							</SourceContext>
							<MpePitchBendUsesTuning Value="true" />
							<ViewData Value="{}" />
							<OverwriteProtectionNumber Value="3075" />
							<PhaseInvertL>
								<LomId Value="0" />
								<Manual Value="false" />
								<AutomationTarget Id="1621">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</PhaseInvertL>
							<PhaseInvertR>
								<LomId Value="0" />
								<Manual Value="false" />
								<AutomationTarget Id="1622">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</PhaseInvertR>
							<ChannelMode>
								<LomId Value="0" />
								<Manual Value="1" />
								<AutomationTarget Id="1623">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiControllerRange>
									<Min Value="0" />
									<Max Value="3" />
								</MidiControllerRange>
							</ChannelMode>
							<StereoWidth>
								<LomId Value="0" />
								<Manual Value="1" />
								<MidiControllerRange>
									<Min Value="0" />
									<Max Value="4" />
								</MidiControllerRange>
								<AutomationTarget Id="1624">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<ModulationTarget Id="1625">
									<LockEnvelope Value="0" />
								</ModulationTarget>
							</StereoWidth>
							<MidSideBalance>
								<LomId Value="0" />
								<Manual Value="1" />
								<MidiControllerRange>
									<Min Value="0" />
									<Max Value="2" />
								</MidiControllerRange>
								<AutomationTarget Id="1626">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<ModulationTarget Id="1627">
									<LockEnvelope Value="0" />
								</ModulationTarget>
							</MidSideBalance>
							<MidSideBalanceOn Value="false" />
							<Mono>
								<LomId Value="0" />
								<Manual Value="false" />
								<AutomationTarget Id="1628">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</Mono>
							<BassMono>
								<LomId Value="0" />
								<Manual Value="false" />
								<AutomationTarget Id="1629">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</BassMono>
							<BassMonoAudition Value="false" />
							<BassMonoFrequency>
								<LomId Value="0" />
								<Manual Value="120" />
								<MidiControllerRange>
									<Min Value="50" />
									<Max Value="500" />
								</MidiControllerRange>
								<AutomationTarget Id="1630">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<ModulationTarget Id="1631">
									<LockEnvelope Value="0" />
								</ModulationTarget>
							</BassMonoFrequency>
							<Balance>
								<LomId Value="0" />
								<Manual Value="0" />
								<MidiControllerRange>
									<Min Value="-1" />
									<Max Value="1" />
								</MidiControllerRange>
								<AutomationTarget Id="1632">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<ModulationTarget Id="1633">
									<LockEnvelope Value="0" />
								</ModulationTarget>
							</Balance>
							<Gain>
								<LomId Value="0" />
								<Manual Value="1" />
								<MidiControllerRange>
									<Min Value="0" />
									<Max Value="56.2341309" />
								</MidiControllerRange>
								<AutomationTarget Id="1634">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<ModulationTarget Id="1635">
									<LockEnvelope Value="0" />
								</ModulationTarget>
							</Gain>
							<LegacyGain>
								<LomId Value="0" />
								<Manual Value="0" />
								<MidiControllerRange>
									<Min Value="-35" />
									<Max Value="35" />
								</MidiControllerRange>
								<AutomationTarget Id="1636">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<ModulationTarget Id="1637">
									<LockEnvelope Value="0" />
								</ModulationTarget>
							</LegacyGain>
							<Mute>
								<LomId Value="0" />
								<Manual Value="false" />
								<AutomationTarget Id="1638">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</Mute>
							<DcFilter>
								<LomId Value="0" />
								<Manual Value="false" />
								<AutomationTarget Id="1639">
									<LockEnvelope Value="0" />
								</AutomationTarget>
								<MidiCCOnOffThresholds>
									<Min Value="64" />
									<Max Value="127" />
								</MidiCCOnOffThresholds>
							</DcFilter>
							<LegacyMode Value="false" />
						</StereoGain>
					</Devices>
					<SignalModulations />
				</DeviceChain>
			</DeviceChain>
		</MainTrack>
		<PreHearTrack SelectedToolPanel="7" SelectedTransformationName="" SelectedGeneratorName="">
			<LomId Value="0" />
			<LomIdView Value="0" />
			<IsContentSelectedInDocument Value="false" />
			<PreferredContentViewMode Value="0" />
			<TrackDelay>
				<Value Value="0" />
				<IsValueSampleBased Value="false" />
			</TrackDelay>
			<Name>
				<EffectiveName Value="0-Main" />
				<UserName Value="" />
				<Annotation Value="" />
				<MemorizedFirstClipName Value="" />
			</Name>
			<Color Value="-1" />
			<AutomationEnvelopes>
				<Envelopes />
			</AutomationEnvelopes>
			<TrackGroupId Value="-1" />
			<TrackUnfolded Value="false" />
			<DevicesListWrapper LomId="0" />
			<ClipSlotsListWrapper LomId="0" />
			<ArrangementClipsListWrapper LomId="0" />
			<TakeLanesListWrapper LomId="0" />
			<ViewData Value="{}" />
			<TakeLanes>
				<TakeLanes />
				<AreTakeLanesFolded Value="true" />
			</TakeLanes>
			<LinkedTrackGroupId Value="-1" />
			<DeviceChain>
				<AutomationLanes>
					<AutomationLanes>
						<AutomationLane Id="0">
							<SelectedDevice Value="0" />
							<SelectedEnvelope Value="0" />
							<IsContentSelectedInDocument Value="false" />
							<LaneHeight Value="85" />
						</AutomationLane>
					</AutomationLanes>
					<AreAdditionalAutomationLanesFolded Value="false" />
				</AutomationLanes>
				<ClipEnvelopeChooserViewState>
					<SelectedDevice Value="0" />
					<SelectedEnvelope Value="0" />
					<PreferModulationVisible Value="false" />
				</ClipEnvelopeChooserViewState>
				<AudioInputRouting>
					<Target Value="AudioIn/External/S0" />
					<UpperDisplayString Value="Ext. In" />
					<LowerDisplayString Value="1/2" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</AudioInputRouting>
				<MidiInputRouting>
					<Target Value="MidiIn/External.All/-1" />
					<UpperDisplayString Value="Ext: All Ins" />
					<LowerDisplayString Value="" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</MidiInputRouting>
				<AudioOutputRouting>
					<Target Value="AudioOut/External/S0" />
					<UpperDisplayString Value="Ext. Out" />
					<LowerDisplayString Value="1/2" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</AudioOutputRouting>
				<MidiOutputRouting>
					<Target Value="MidiOut/None" />
					<UpperDisplayString Value="None" />
					<LowerDisplayString Value="" />
					<MpeSettings>
						<ZoneType Value="0" />
						<FirstNoteChannel Value="1" />
						<LastNoteChannel Value="15" />
					</MpeSettings>
					<MpePitchBendUsesTuning Value="true" />
				</MidiOutputRouting>
				<Mixer>
					<LomId Value="0" />
					<LomIdView Value="0" />
					<IsExpanded Value="true" />
					<BreakoutIsExpanded Value="false" />
					<On>
						<LomId Value="0" />
						<Manual Value="true" />
						<AutomationTarget Id="850">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiCCOnOffThresholds>
							<Min Value="64" />
							<Max Value="127" />
						</MidiCCOnOffThresholds>
					</On>
					<ModulationSourceCount Value="0" />
					<ParametersListWrapper LomId="0" />
					<Pointee Id="10515" />
					<LastSelectedTimeableIndex Value="0" />
					<LastSelectedClipEnvelopeIndex Value="0" />
					<LastPresetRef>
						<Value />
					</LastPresetRef>
					<LockedScripts />
					<IsFolded Value="false" />
					<ShouldShowPresetName Value="false" />
					<UserName Value="" />
					<Annotation Value="" />
					<SourceContext>
						<Value />
					</SourceContext>
					<MpePitchBendUsesTuning Value="true" />
					<ViewData Value="{}" />
					<Sends />
					<Speaker>
						<LomId Value="0" />
						<Manual Value="true" />
						<AutomationTarget Id="851">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiCCOnOffThresholds>
							<Min Value="64" />
							<Max Value="127" />
						</MidiCCOnOffThresholds>
					</Speaker>
					<SoloSink Value="false" />
					<PanMode Value="0" />
					<Pan>
						<LomId Value="0" />
						<Manual Value="0" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="852">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="144">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</Pan>
					<SplitStereoPanL>
						<LomId Value="0" />
						<Manual Value="-1" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="853">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="854">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</SplitStereoPanL>
					<SplitStereoPanR>
						<LomId Value="0" />
						<Manual Value="1" />
						<MidiControllerRange>
							<Min Value="-1" />
							<Max Value="1" />
						</MidiControllerRange>
						<AutomationTarget Id="855">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="856">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</SplitStereoPanR>
					<Volume>
						<LomId Value="0" />
						<Manual Value="1" />
						<MidiControllerRange>
							<Min Value="0.00031622799" />
							<Max Value="1.99526203" />
						</MidiControllerRange>
						<AutomationTarget Id="857">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<ModulationTarget Id="145">
							<LockEnvelope Value="0" />
						</ModulationTarget>
					</Volume>
					<ViewStateSessionTrackWidth Value="74" />
					<CrossFadeState>
						<LomId Value="0" />
						<Manual Value="1" />
						<AutomationTarget Id="858">
							<LockEnvelope Value="0" />
						</AutomationTarget>
						<MidiControllerRange>
							<Min Value="0" />
							<Max Value="2" />
						</MidiControllerRange>
					</CrossFadeState>
					<SendsListWrapper LomId="0" />
				</Mixer>
				<DeviceChain>
					<Devices />
					<SignalModulations />
				</DeviceChain>
			</DeviceChain>
		</PreHearTrack>
		<SendsPre>
			<SendPreBool Id="0" Value="false" />
			<SendPreBool Id="2" Value="false" />
		</SendsPre>
		<Scenes>
			<Scene Id="0">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="1">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="2">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="3">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="4">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="5">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="6">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
			<Scene Id="7">
				<FollowAction>
					<FollowTime Value="4" />
					<IsLinked Value="true" />
					<LoopIterations Value="1" />
					<FollowActionA Value="4" />
					<FollowActionB Value="0" />
					<FollowChanceA Value="100" />
					<FollowChanceB Value="0" />
					<JumpIndexA Value="0" />
					<JumpIndexB Value="0" />
					<FollowActionEnabled Value="false" />
				</FollowAction>
				<Name Value="" />
				<Annotation Value="" />
				<Color Value="-1" />
				<Tempo Value="120" />
				<IsTempoEnabled Value="false" />
				<TimeSignatureId Value="201" />
				<IsTimeSignatureEnabled Value="false" />
				<LomId Value="0" />
				<ClipSlotsListWrapper LomId="0" />
			</Scene>
		</Scenes>
		<Transport>
			<PhaseNudgeTempo Value="10" />
			<LoopOn Value="false" />
			<LoopStart Value="8" />
			<LoopLength Value="16" />
			<LoopIsSongStart Value="false" />
			<CurrentTime Value="44" />
			<PunchIn Value="false" />
			<PunchOut Value="false" />
			<MetronomeTickDuration Value="0" />
			<DrawMode Value="false" />
		</Transport>
		<SessionScrollPos X="0" Y="0" />
		<SelectedBreakpointValue Value="0" />
		<SignalModulations />
		<GlobalQuantisation Value="4" />
		<AutoQuantisation Value="0" />
		<Grid>
			<FixedNumerator Value="1" />
			<FixedDenominator Value="16" />
			<GridIntervalPixel Value="20" />
			<Ntoles Value="2" />
			<SnapToGrid Value="true" />
			<Fixed Value="false" />
		</Grid>
		<ScaleInformation>
			<Root Value="0" />
			<Name Value="0" />
		</ScaleInformation>
		<InKey Value="true" />
		<SmpteFormat Value="0" />
		<TimeSelection>
			<AnchorTime Value="44" />
			<OtherTime Value="44" />
		</TimeSelection>
		<SequencerNavigator>
			<BeatTimeHelper>
				<CurrentZoom Value="0.254945054945054927" />
			</BeatTimeHelper>
			<ScrollerPos X="0" Y="0" />
			<ClientSize X="1675" Y="898" />
		</SequencerNavigator>
		<IsContentSplitterOpen Value="true" />
		<IsExpressionSplitterOpen Value="true" />
		<ExpressionLanes>
			<MidiEditorLaneModel Id="0">
				<Type Value="0" />
				<Size Value="41" />
				<IsMinimized Value="false" />
			</MidiEditorLaneModel>
			<MidiEditorLaneModel Id="1">
				<Type Value="1" />
				<Size Value="41" />
				<IsMinimized Value="false" />
			</MidiEditorLaneModel>
			<MidiEditorLaneModel Id="2">
				<Type Value="2" />
				<Size Value="41" />
				<IsMinimized Value="true" />
			</MidiEditorLaneModel>
			<MidiEditorLaneModel Id="3">
				<Type Value="3" />
				<Size Value="41" />
				<IsMinimized Value="true" />
			</MidiEditorLaneModel>
			<MidiEditorLaneModel Id="4">
				<Type Value="5" />
				<Size Value="41" />
				<IsMinimized Value="true" />
			</MidiEditorLaneModel>
		</ExpressionLanes>
		<ContentLanes>
			<MidiEditorLaneModel Id="0">
				<Type Value="2" />
				<Size Value="41" />
				<IsMinimized Value="false" />
			</MidiEditorLaneModel>
			<MidiEditorLaneModel Id="2">
				<Type Value="3" />
				<Size Value="25" />
				<IsMinimized Value="true" />
			</MidiEditorLaneModel>
			<MidiEditorLaneModel Id="1">
				<Type Value="4" />
				<Size Value="25" />
				<IsMinimized Value="true" />
			</MidiEditorLaneModel>
		</ContentLanes>
		<ViewStateFxSlotCount Value="4" />
		<ViewStateSessionMixerVolumeSectionHeight Value="156" />
		<ViewStateArrangerMixerVolumeSectionHeight Value="120" />
		<ShouldSceneTempoAndTimeSignatureBeVisible Value="false" />
		<WaveformVerticalZoomFactor Value="1" />
		<IsWaveformVerticalZoomActive Value="true" />
		<Locators>
			<Locators />
		</Locators>
		<DetailClipKeyMidis />
		<TracksListWrapper LomId="0" />
		<VisibleTracksListWrapper LomId="0" />
		<ReturnTracksListWrapper LomId="0" />
		<ScenesListWrapper LomId="0" />
		<CuePointsListWrapper LomId="0" />
		<SelectedDocumentViewInMainWindow Value="0" />
		<Annotation Value="" />
		<SoloOrPflSavedValue Value="true" />
		<SoloInPlace Value="true" />
		<CrossfadeCurve Value="2" />
		<LatencyCompensation Value="1" />
		<HighlightedTrackIndex Value="0" />
		<GroovePool>
			<LomId Value="0" />
			<Grooves />
			<DefaultGrooveId Value="-1" />
			<GroovesListWrapper LomId="0" />
		</GroovePool>
		<AutomationMode Value="false" />
		<SnapAutomationToGrid Value="true" />
		<ArrangementOverdub Value="false" />
		<ColorSequenceIndex Value="4" />
		<AutoColorPickerForPlayerAndGroupTracks>
			<NextColorIndex Value="9" />
		</AutoColorPickerForPlayerAndGroupTracks>
		<AutoColorPickerForReturnAndMainTracks>
			<NextColorIndex Value="2" />
		</AutoColorPickerForReturnAndMainTracks>
		<ViewData Value="{}" />
		<ResetNonautomatedMidiControllersOnClipStarts Value="true" />
		<MidiFoldIn Value="false" />
		<MidiFoldMode Value="-99" />
		<MultiClipFocusMode Value="false" />
		<MultiClipLoopBarHeight Value="0" />
		<MidiPrelisten Value="false" />
		<LinkedTrackGroups />
		<NoteSpellingPreference Value="0" />
		<AccidentalSpellingPreference Value="3" />
		<PreferFlatRootNote Value="false" />
		<UseWarperLegacyHiQMode Value="false" />
		<VideoWindowRect Top="-2147483648" Left="-2147483648" Bottom="-2147483648" Right="-2147483648" />
		<ShowVideoWindow Value="true" />
		<TuningSystems />
		<TrackHeaderWidth Value="93" />
		<ViewStateMainWindowClipDetailOpen Value="false" />
		<ViewStateMainWindowHiddenOtherDocViewTypeClipDetailOpen Value="false" />
		<ViewStateMainWindowHiddenOtherDocViewTypeDeviceDetailOpen Value="true" />
		<ViewStateMainWindowDeviceDetailOpen Value="true" />
		<ViewStateSecondWindowClipDetailOpen Value="true" />
		<ViewStateSecondWindowDeviceDetailOpen Value="false" />
		<ViewStates>
			<MixerInArrangement Value="1" />
			<ArrangerMixerIO Value="1" />
			<ArrangerMixerSends Value="1" />
			<ArrangerMixerReturns Value="1" />
			<ArrangerMixerVolume Value="1" />
			<ArrangerMixerTrackOptions Value="0" />
			<ArrangerMixerCrossFade Value="0" />
			<ArrangerMixerTrackPerformanceImpactMeter Value="0" />
			<MixerInSession Value="1" />
			<SessionIO Value="1" />
			<SessionSends Value="1" />
			<SessionReturns Value="1" />
			<SessionVolume Value="1" />
			<SessionTrackOptions Value="0" />
			<SessionCrossFade Value="0" />
			<SessionTrackPerformanceImpactMeter Value="0" />
			<SessionShowOverView Value="0" />
			<ArrangerIO Value="1" />
			<ArrangerReturns Value="1" />
			<ArrangerVolume Value="1" />
			<ArrangerTrackOptions Value="0" />
			<ArrangerShowOverView Value="1" />
		</ViewStates>
		<NoteAlgorithms>
			<ArpeggiateAlgorithm Id="0">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="35" Name="Rate" />
					<NamedRemoteableKeyMidi Id="36" Name="Steps" />
					<NamedRemoteableKeyMidi Id="37" Name="Distance" />
					<NamedRemoteableKeyMidi Id="38" Name="Gate" />
					<NamedRemoteableKeyMidi Id="39" Name="Style" />
				</NamedKeyMidiRemoteables>
				<Rate Value="0" />
				<Steps Value="2" />
				<Distance Value="12" />
				<Gate Value="1" />
				<Style Value="0" />
			</ArpeggiateAlgorithm>
			<SpanAlgorithm Id="1">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="21" Name="Mode" />
					<NamedRemoteableKeyMidi Id="22" Name="LengthVariation" />
					<NamedRemoteableKeyMidi Id="23" Name="LengthOffset" />
				</NamedKeyMidiRemoteables>
				<Mode Value="1" />
				<ChordThreshold Value="10" />
				<LengthVariation Value="0" />
				<LengthOffset Value="0" />
			</SpanAlgorithm>
			<OrnamentAlgorithm Id="2">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="63" Name="FlamEnabled" />
					<NamedRemoteableKeyMidi Id="64" Name="FlamPosition" />
					<NamedRemoteableKeyMidi Id="65" Name="FlamVelocity" />
					<NamedRemoteableKeyMidi Id="66" Name="GraceNotesEnabled" />
					<NamedRemoteableKeyMidi Id="67" Name="GraceNotesChance" />
					<NamedRemoteableKeyMidi Id="68" Name="GraceNotesVelocity" />
					<NamedRemoteableKeyMidi Id="69" Name="GraceNotesPosition" />
					<NamedRemoteableKeyMidi Id="70" Name="GraceNotesAmount" />
					<NamedRemoteableKeyMidi Id="71" Name="GraceNotesPitch" />
				</NamedKeyMidiRemoteables>
				<FlamEnabled Value="false" />
				<FlamPosition Value="0.200000003" />
				<FlamVelocity Value="0.1000000015" />
				<GraceNotesEnabled Value="true" />
				<GraceNotesChance Value="1" />
				<GraceNotesVelocity Value="0.1000000015" />
				<GraceNotesPosition Value="0.200000003" />
				<GraceNotesAmount Value="3" />
				<GraceNotesPitch Value="1" />
			</OrnamentAlgorithm>
			<RecombineAlgorithm Id="3">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="35" Name="Dimension" />
					<NamedRemoteableKeyMidi Id="36" Name="Shuffle" />
					<NamedRemoteableKeyMidi Id="37" Name="Mirror" />
					<NamedRemoteableKeyMidi Id="38" Name="RotateAmount" />
					<NamedRemoteableKeyMidi Id="39" Name="RotateOnGrid" />
				</NamedKeyMidiRemoteables>
				<PermutedDimension Value="0" />
				<Shuffle Value="false" />
				<Mirror Value="false" />
				<RotateAmount Value="0" />
				<RotateOnGrid Value="false" />
			</RecombineAlgorithm>
			<QuantizeAlgorithm Id="4">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="35" Name="TripletReference" />
					<NamedRemoteableKeyMidi Id="36" Name="QuantizeReference" />
					<NamedRemoteableKeyMidi Id="37" Name="Amount" />
					<NamedRemoteableKeyMidi Id="38" Name="QuantizeNoteStarts" />
					<NamedRemoteableKeyMidi Id="39" Name="QuantizeNoteEnds" />
				</NamedKeyMidiRemoteables>
				<Reference Value="5" />
				<TripletReference Value="false" />
				<QuantizeNoteStarts Value="true" />
				<QuantizeNoteEnds Value="false" />
				<Amount Value="58.7301598" />
			</QuantizeAlgorithm>
			<TimeWarpAlgorithm Id="5">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="147" Name="StretchNoteEnd" />
					<NamedRemoteableKeyMidi Id="148" Name="PreserveTimeRange" />
					<NamedRemoteableKeyMidi Id="149" Name="Quantize" />
					<NamedRemoteableKeyMidi Id="150" Name="Value1" />
					<NamedRemoteableKeyMidi Id="151" Name="Time1" />
					<NamedRemoteableKeyMidi Id="152" Name="IsActive1" />
					<NamedRemoteableKeyMidi Id="153" Name="Value2" />
					<NamedRemoteableKeyMidi Id="154" Name="Time2" />
					<NamedRemoteableKeyMidi Id="155" Name="IsActive2" />
					<NamedRemoteableKeyMidi Id="156" Name="Value3" />
					<NamedRemoteableKeyMidi Id="157" Name="Time3" />
					<NamedRemoteableKeyMidi Id="158" Name="IsActive3" />
				</NamedKeyMidiRemoteables>
				<Breakpoints>
					<Breakpoint Id="0">
						<Value Value="0.5" />
						<Time Value="0" />
						<Control1X Value="0.5" />
						<Control1Y Value="0.5" />
						<Control2X Value="0.5" />
						<Control2Y Value="0.5" />
						<IsActive Value="true" />
					</Breakpoint>
					<Breakpoint Id="1">
						<Value Value="0.5" />
						<Time Value="0.5" />
						<Control1X Value="0.5" />
						<Control1Y Value="0.5" />
						<Control2X Value="0.5" />
						<Control2Y Value="0.5" />
						<IsActive Value="false" />
					</Breakpoint>
					<Breakpoint Id="2">
						<Value Value="0.5" />
						<Time Value="1" />
						<Control1X Value="0.5" />
						<Control1Y Value="0.5" />
						<Control2X Value="0.5" />
						<Control2Y Value="0.5" />
						<IsActive Value="true" />
					</Breakpoint>
				</Breakpoints>
				<StretchNoteEnd Value="true" />
				<PreserveTimeRange Value="true" />
				<Quantize Value="false" />
			</TimeWarpAlgorithm>
			<RhythmAlgorithm Id="6">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="98" Name="Density" />
					<NamedRemoteableKeyMidi Id="99" Name="Repetitions" />
					<NamedRemoteableKeyMidi Id="100" Name="Pattern" />
					<NamedRemoteableKeyMidi Id="101" Name="Steps" />
					<NamedRemoteableKeyMidi Id="102" Name="Pitch" />
					<NamedRemoteableKeyMidi Id="103" Name="Velocity" />
					<NamedRemoteableKeyMidi Id="104" Name="Accent" />
					<NamedRemoteableKeyMidi Id="105" Name="Period" />
					<NamedRemoteableKeyMidi Id="106" Name="Offset" />
					<NamedRemoteableKeyMidi Id="107" Name="Shift" />
					<NamedRemoteableKeyMidi Id="108" Name="StepDuration" />
					<NamedRemoteableKeyMidi Id="109" Name="Split" />
					<NamedRemoteableKeyMidi Id="110" Name="VelocityOffsetIncrement" />
					<NamedRemoteableKeyMidi Id="111" Name="VelocityOffsetDecrement" />
				</NamedKeyMidiRemoteables>
				<Density Value="4" />
				<Repetitions Value="1" />
				<Pattern Value="14" />
				<PatternLength Value="8" />
				<Pitch Value="36" />
				<Velocity Value="100" />
				<Accent Value="127" />
				<Period Value="4" />
				<Offset Value="0" />
				<Shift Value="0" />
				<StepDuration Value="7" />
				<Split Value="0" />
			</RhythmAlgorithm>
			<StacksAlgorithm Id="7">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="84" Name="AppendChord" />
					<NamedRemoteableKeyMidi Id="85" Name="DeleteSelectedChord" />
					<NamedRemoteableKeyMidi Id="86" Name="RootPitch1" />
					<NamedRemoteableKeyMidi Id="87" Name="Inversion1" />
					<NamedRemoteableKeyMidi Id="88" Name="Rule1" />
					<NamedRemoteableKeyMidi Id="89" Name="Duration1" />
					<NamedRemoteableKeyMidi Id="90" Name="Offset1" />
				</NamedKeyMidiRemoteables>
				<Sequence>
					<Chord Id="1">
						<RootDegree Value="0" />
						<Octave Value="3" />
						<RootPitch Value="60" />
						<Inversion Value="0" />
						<RuleNumber Value="0" />
						<Duration Value="1" />
						<Offset Value="0" />
					</Chord>
				</Sequence>
			</StacksAlgorithm>
			<ShapeAlgorithm Id="8">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="49" Name="ShapePresets" />
					<NamedRemoteableKeyMidi Id="50" Name="Rate" />
					<NamedRemoteableKeyMidi Id="51" Name="Tie" />
					<NamedRemoteableKeyMidi Id="52" Name="Density" />
					<NamedRemoteableKeyMidi Id="53" Name="MinPitch" />
					<NamedRemoteableKeyMidi Id="54" Name="MaxPitch" />
					<NamedRemoteableKeyMidi Id="55" Name="PitchVariation" />
				</NamedKeyMidiRemoteables>
				<ShapeLevels>
					<RemoteableFloat Id="0" Value="0" />
					<RemoteableFloat Id="1" Value="0.04761904851" />
					<RemoteableFloat Id="2" Value="0.09523809701" />
					<RemoteableFloat Id="3" Value="0.1428571492" />
					<RemoteableFloat Id="4" Value="0.190476194" />
					<RemoteableFloat Id="5" Value="0.2380952388" />
					<RemoteableFloat Id="6" Value="0.2857142985" />
					<RemoteableFloat Id="7" Value="0.3333333433" />
					<RemoteableFloat Id="8" Value="0.380952388" />
					<RemoteableFloat Id="9" Value="0.4285714328" />
					<RemoteableFloat Id="10" Value="0.4761904776" />
					<RemoteableFloat Id="11" Value="0.5238095522" />
					<RemoteableFloat Id="12" Value="0.571428597" />
					<RemoteableFloat Id="13" Value="0.6190476418" />
					<RemoteableFloat Id="14" Value="0.6666666865" />
					<RemoteableFloat Id="15" Value="0.7142857313" />
					<RemoteableFloat Id="16" Value="0.7619047761" />
					<RemoteableFloat Id="17" Value="0.8095238209" />
					<RemoteableFloat Id="18" Value="0.8571428657" />
					<RemoteableFloat Id="19" Value="0.9047619104" />
					<RemoteableFloat Id="20" Value="0.9523809552" />
				</ShapeLevels>
				<ShapePresets Value="2" />
				<Rate Value="0" />
				<Tie Value="0" />
				<Density Value="100" />
				<MinPitch Value="60" />
				<MaxPitch Value="84" />
				<PitchVariation Value="0" />
			</ShapeAlgorithm>
			<SeedAlgorithm Id="9">
				<NamedKeyMidiRemoteables>
					<NamedRemoteableKeyMidi Id="56" Name="Density" />
					<NamedRemoteableKeyMidi Id="57" Name="MinPitch" />
					<NamedRemoteableKeyMidi Id="58" Name="MaxPitch" />
					<NamedRemoteableKeyMidi Id="59" Name="MinDuration" />
					<NamedRemoteableKeyMidi Id="60" Name="MaxDuration" />
					<NamedRemoteableKeyMidi Id="61" Name="MinVelocity" />
					<NamedRemoteableKeyMidi Id="62" Name="MaxVelocity" />
					<NamedRemoteableKeyMidi Id="63" Name="VerticalLimit" />
				</NamedKeyMidiRemoteables>
				<NotesDensity Value="0.5" />
				<MinPitch Value="58" />
				<MaxPitch Value="84" />
				<MinDuration Value="-6" />
				<MaxDuration Value="-3" />
				<MinVelocity Value="1" />
				<MaxVelocity Value="127" />
				<VerticalLimit Value="4" />
			</SeedAlgorithm>
		</NoteAlgorithms>
	</LiveSet>
</Ableton>
